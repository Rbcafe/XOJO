RB-FTP
======
This project aims to provide both FTP client and FTP server capabilities for Realbasic without reliance on a third-party plugin or library.

Client sessions use the [FTPClientSocket](https://github.com/charonn0/RB-FTP/wiki/FTPClientSocket) class whereas server sessions use the (incomplete) [FTPServerSocket](https://github.com/charonn0/RB-FTP/wiki/FTPServerSocket). 

The [FTPSocket](https://github.com/charonn0/RB-FTP/wiki/FTPSocket) provides the superclass for both client and server sockets.