#import "AboutController.h"

@implementation AboutController

- (id)init
{
	self = [super initWithWindowNibName:@"About"];
	return self;
}

@end
