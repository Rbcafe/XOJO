Some notes on the RB Project Tools

(as of Version 1.1.7)


More infos
===========

See this page for infos about these tools:

	<http://www.tempel.org/RBProjectTools>


About "RB Prj Vault ExIm CUI.rbp"
==================================

Note:
  This CUI version compiles only with RB 2005r4 and later but not
  with RB 5.5.5.
  It should run on OS X and Windows 2000.

This is a command line tool (console app) that read/writes project
files to .rbvault folders for use with Version Control tools such as
SubVersion and CVS.

To use it, build it first, then call it from the command line.
Due to the weird way RB builds it on Mac OS, you need to call it
inside its folder, like this:

  ./rbpvexim/rbpvexim

When running it, you'll get usage information shown.

Generally, it works just like the interactive way explained below
for the "RB Project Tool": You tell it whether to export or import
and pass the prj file or vault directory to it.

See below for how to use it with a Version Control tool.


About "RB Prj Vault ExIm GUI.rbp"
==================================

It has a similar functionality to the CUI version, only that it
has a interactive user interface instead of requiring a command
shell for use. See the Documentation module inside the project
file for more information.


About "RB Project Tool.rbp"
============================

Provides a user interface through which you can do a lot of things
with project files.

  This code compiles with both RB 5.5.5 and 2007r2.
  Should run on Mac OS 9, OS X and Windows 2000

Here's how to use it for Version Controlling:
---------------------------------------------

1. Run it. Drop a binary (not XML!) .rb or .rbp file onto the "Export to 
Vault" field.
The first time you do this, you'll get a msg that a "vault" folders was
created. You'll now see a new folder ending in ".rbvault" where your .rbp
file is.

2. Look into the .rbvault folder. You'll find a file there for every item 
(windows, classes etc.) in your project. You can view them with a text 
editor. They contain exactly all items from your project file, in a more 
readable form.

3. Import all files inside the ".rbvault" folder into your repository.
(If you use svn, you must then check out the project again before you
can use svn with the vault.)

4. Now you can make changes to your project. Whenever you want to check 
it in, first use this tool's "export to vault", which will update the
changed items from the prj file. Then check the items from the vault
into the repository. 

5. After checking out from the repository, use this tool's "import from 
vault" and it'll generate a new ".rbp" file (or .xml, if you prefer, see 
the checkbox), replacing the old version.

See how that works for you. Try working with two local copies, making 
changes to one copy, then to the other, and see how your version control 
software deals with merging them.


Attention
==========


Warnings vs. Errors
-------------------

The process can show warnings as well as errors. Errors mean that the
process was not successful at all, while warnings imply that the
process worked in general but that you should be aware of certain
oddities in the process.


Only binary prj files, no XML!
------------------------------

So far, the input files must be non-XML files. My code will eventually
be able to scan XML files as well, but it's not there yet. So, if you
want to use version control with this tool, store your prj files and
all externals in standard format and not in XML format.


Vault Export and Import with External Items
-------------------------------------------

The Vault Ex/Import feature of these tools can also handle external items.
But if you'd then try to use them with a version control
system such as SubVersion or CVS, it gets complicated easily.

Therefore, the following rules are currently applied when you export or import a
RB project to the "vault" folder for version control:

On Export To Vault:
- All items of the project, including the external items, will be stored inside the
  vault folder next to the main project file.

On Import From Vault:
- If an external item was stored in a folder that is in the same or a deeper folder
  from there the main project file is located, then it will be restored in the same
  place (and folders will be recreated as necessary)
- If an external item was stored in a folder outside of the main project's folder,
  and if that folder is not accessible, then it will be created in a new folder called
  "Relocated External Items" next to the main project file.


Safety
------

The export is self-verifying, ensuring that you can't lose your data.

In order to achieve this safety, the code that writes the files to the
vault reads them back afterwards and recreates a project (including
externals) inside the TemporaryFolder. Then it compares the original
project with this copy. If they do not match, something went wrong in
the tool's code code and you'll be notified.

So, unless you get an error message, you can be pretty sure that you'll
later be able to restore your project from it, without loss of any relevant
information (remark: the group IDs get lost but they are irrelevant - XML
prj files do lose them as well, so no worries here).


Enjoy!
 Thomas  (rb@tempel.org)
