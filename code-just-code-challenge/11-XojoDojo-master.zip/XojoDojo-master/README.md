# XojoDojo

Xojo Dojo is a free and easy way to get started with programming on the Raspberry Pi. With Xojo Dojo you can use the Xojo programming language, along with a few other special commands to make simple Pi programs that can use text, graphics and GPIO.

Made open-source as part of Xojo 2018 Just Code Challenge.

## Documentation

https://docs.xojo.com/UserGuide:Xojo_Dojo

## Binary Download
http://cdn.xojo.com/Documentation/XojoDojoV1.0.0.zip

