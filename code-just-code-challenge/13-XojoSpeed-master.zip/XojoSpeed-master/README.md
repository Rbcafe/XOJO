# XojoSpeed

Xojo Speed: A simple speedometer iOS application made with the [Xojo programming language](http://www.xojo.com).

This simple program uses the GPS to get location and converts the meters per second to km per hour or miles per hour.

