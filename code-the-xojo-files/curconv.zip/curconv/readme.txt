To make things work you must copy some files to /opt

cp -r curconv /opt
