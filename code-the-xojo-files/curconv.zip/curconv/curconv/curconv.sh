#!/bin/bash
 
# 2009 - Rafa Casado - http://bit.ly/bYZwex
# 2010 - Chris Ergatides - http://bit.ly/9XjAUz
 
if [ $# -lt 2 ]; then
    echo -e "\nUsage: $0 currency1 currency2 amount"
    echo "Default: $0 GBP EUR 1"
    echo "Example 1: $0 USD GBP"
    echo "Example 2: $0 GBP USD 42"
fi
 
toUpper() {
    echo $@ | tr "[:lower:]" "[:upper:]"
}
 
if [ -n "$1" ]; then FROM=$(toUpper "$1"); else FROM=GBP; fi
if [ -n "$2" ]; then TO=$(toUpper "$2"); else TO=EUR; fi
if [ $TO == $FROM ]; then echo 'Nothing to do!'; exit 2; fi
if [ -n "$3" ]; then A=$3; else A=1; fi
 
CONVERTER="http://www.google.com/finance/converter?a=$A&from=$FROM&to=$TO"
 
RESULT=`wget -nv -O - "$CONVERTER" 2>&1 | \
sed -n -e 's/.*<span class=bld>\(.*\)<\/span>.*/\1/p'`
 
echo -e "$A $FROM = $RESULT\n"


