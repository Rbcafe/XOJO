In order to be able to use this program you must download poweriso from www.poweriso.com and put it in /usr/bin.
