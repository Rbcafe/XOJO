//
//  OrderedDictionary.m
//  OrderedDictionary
//
//  Created by Nick Lockwood on 21/09/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "OrderedDictionary.h"


@interface OrderedDictionaryReverseObjectEnumerator : NSEnumerator {	
	
	NSArray *_keys;
	NSDictionary *_values;
	NSInteger _index;
}

+ (id)enumeratorWithKeys:(NSArray *)keys values:(NSDictionary *)values;
- (id)initWithKeys:(NSArray *)keys values:(NSDictionary *)values;

@end


@implementation OrderedDictionaryReverseObjectEnumerator

+ (id)enumeratorWithKeys:(NSArray *)keys values:(NSDictionary *)values {

	return [[[self alloc] initWithKeys:keys values:values] autorelease];
}

- (id)initWithKeys:(NSArray *)keys values:(NSDictionary *)values {

	if ((self = [super init])) {
		
		//retain is more efficient than copy, but less safe
		//because we don't copy, it's not safe to modify the dictionary
		//during enumeration - this is also true for an NSMutableDictionary
		_keys = [keys retain];
		_values = [values retain];
		_index = [keys count] - 1;
	}
	return self;
}

- (id)nextObject {
	
	return (_index < 0)? nil: [_values objectForKey:[_keys objectAtIndex:_index--]];
}

- (void)dealloc {
	
	[_keys release];
	[_values release];
	[super dealloc];
}

@end


NSString *_description(id object, id locale, NSUInteger indent) {
	
	if ([object respondsToSelector:@selector(descriptionWithLocale:indent:)]) {
		return [object descriptionWithLocale:locale indent:indent];
	}
	else if ([object respondsToSelector:@selector(descriptionWithLocale:)]) {
		return [object descriptionWithLocale:locale];
	}
	else {
		return [object description];
	}
}


@implementation OrderedDictionary

- (id)initWithObjects:(id *)objects forKeys:(id *)keys count:(NSUInteger)count {
	
	if ((self = [super init])) {
		
		_values = [[NSMutableDictionary alloc] initWithCapacity:count];
		_keys = [[NSMutableArray alloc] initWithCapacity:count];
		for (NSUInteger i = 0; i < count; i++) {
			if (![_values objectForKey:keys[i]]) {
				[_keys addObject:keys[i]];
			}
			[_values setObject:objects[i] forKey:keys[i]];
		}
	}
	return self;
}

- (id)copyWithZone:(NSZone *)zone {
	
	return [[[self class] allocWithZone:zone] initWithDictionary:self];
}

- (NSUInteger)count {
	
	return [_keys count];
}

- (id)objectForKey:(id)key {
	
	return [_values objectForKey:key];
}

- (NSEnumerator *)keyEnumerator {
	
	return [_keys objectEnumerator];
}

- (NSEnumerator *)reverseKeyEnumerator {
	
	return [_keys reverseObjectEnumerator];
}

- (NSEnumerator *)reverseObjectEnumerator {
	
	return [OrderedDictionaryReverseObjectEnumerator enumeratorWithKeys:_keys values:_values];
}

- (id)keyAtIndex:(NSUInteger)index {
	
	return [_keys objectAtIndex:index];
}

- (id)objectAtIndex:(NSUInteger)index {
	
	return [_values	objectForKey:[_keys objectAtIndex:index]];
}

- (NSString *)descriptionWithLocale:(id)locale indent:(NSUInteger)indent {
	
	NSMutableString *padding = [NSMutableString string];
	for (NSUInteger i = 0; i < indent; i++) {
		[padding appendString:@"    "];
	}
	
	NSMutableString *description = [NSMutableString string];
	[description appendFormat:@"%@{\n", padding];
	for (NSObject *key in _keys) {
		[description appendFormat:@"%@    %@ = %@;\n", padding,
		 _description(key, locale, indent), _description([self objectForKey:key], locale, indent)];
	}
	[description appendFormat:@"%@}\n", padding];
	
	return description;
}

- (void)dealloc {
	
	[_values release];
	[_keys release];
	[super dealloc];
}

@end


@implementation MutableOrderedDictionary

- (id)initWithCapacity:(NSUInteger)capacity {
	
	if ((self = [super init])) {
		
		_values = [[NSMutableDictionary alloc] initWithCapacity:capacity];
		_keys = [[NSMutableArray alloc] initWithCapacity:capacity];
	}
	return self;
}

- (void)addEntriesFromDictionary:(NSDictionary *)otherDictionary {

	for (id key in [otherDictionary allKeys]) {
		[self setObject:[otherDictionary objectForKey:key] forKey:key];
	}
}

- (void)insertObject:(id)object forKey:(id)key atIndex:(NSUInteger)index {

	if ([_values objectForKey:key]) {
		if ([[_keys objectAtIndex:index] isEqual:key]) {
			[_values setObject:object forKey:key];
			return;
		}
		[self removeObjectForKey:key];
	}
	[_keys insertObject:key atIndex:index];
	[_values setObject:object forKey:key];
}

- (void)removeAllObjects {

	[self removeObjectsForKeys:[self allKeys]];
}

- (void)removeObjectAtIndex:(NSUInteger)index {

	[self removeObjectForKey:[self keyAtIndex:index]];
}

- (void)removeObjectForKey:(id)key {
	
	[_values removeObjectForKey:key];
	[_keys removeObject:key];
}

- (void)removeObjectsForKeys:(NSArray *)keyArray {
	
	NSArray *keys = [keyArray copy];
	for (id key in keys) {
		[self removeObjectForKey:key];
	}
	[keys release];
}

- (void)setDictionary:(NSDictionary *)otherDictionary {

	[self removeAllObjects];
	[self addEntriesFromDictionary:otherDictionary];
}

- (void)setObject:(id)object forKey:(id)key {
	
	if (![_values objectForKey:key]) {
		[_keys addObject:key];
	}
	[_values setObject:object forKey:key];
}

- (void)setValue:(id)value forKey:(NSString *)key {

	if (value) {
		[self setObject:value forKey:key];
	} else {
		[self removeObjectForKey:key];
	}
}

@end


@implementation OrderedMutableDictionary

- (id)initWithCapacity:(NSUInteger)capacity {
	
	if ((self = [super init])) {
		
		_values = [[NSMutableDictionary alloc] initWithCapacity:capacity];
		_keys = [[NSMutableArray alloc] initWithCapacity:capacity];
	}
	return self;
}

- (id)copyWithZone:(NSZone *)zone {
	
	return [[[self class] allocWithZone:zone] initWithDictionary:self];
}

- (NSUInteger)count {
	
	return [_keys count];
}

- (id)objectForKey:(id)key {
	
	return [_values objectForKey:key];
}

- (NSEnumerator *)keyEnumerator {
	
	return [_keys objectEnumerator];
}

- (NSEnumerator *)reverseKeyEnumerator {
	
	return [_keys reverseObjectEnumerator];
}

- (NSEnumerator *)reverseObjectEnumerator {
	
	return [OrderedDictionaryReverseObjectEnumerator enumeratorWithKeys:_keys values:_values];
}

- (id)keyAtIndex:(NSUInteger)index {
	
	return [_keys objectAtIndex:index];
}

- (id)objectAtIndex:(NSUInteger)index {
	
	return [_values	objectForKey:[_keys objectAtIndex:index]];
}

- (NSString *)descriptionWithLocale:(id)locale indent:(NSUInteger)indent {
	
	NSMutableString *padding = [NSMutableString string];
	for (NSUInteger i = 0; i < indent; i++) {
		[padding appendString:@"    "];
	}
	
	NSMutableString *description = [NSMutableString string];
	[description appendFormat:@"%@{\n", padding];
	for (NSObject *key in _keys) {
		[description appendFormat:@"%@    %@ = %@;\n", padding,
		 _description(key, locale, indent), _description([self objectForKey:key], locale, indent)];
	}
	[description appendFormat:@"%@}\n", padding];
	
	return description;
}

- (void)insertObject:(id)object forKey:(id)key atIndex:(NSUInteger)index {
	
	if ([_values objectForKey:key]) {
		if ([[_keys objectAtIndex:index] isEqual:key]) {
			[_values setObject:object forKey:key];
			return;
		}
		[self removeObjectForKey:key];
	}
	[_keys insertObject:key atIndex:index];
	[_values setObject:object forKey:key];
}

- (void)removeObjectAtIndex:(NSUInteger)index {
	
	[self removeObjectForKey:[self keyAtIndex:index]];
}

- (void)removeObjectForKey:(id)key {
	
	[_values removeObjectForKey:key];
	[_keys removeObject:key];
}

- (void)setObject:(id)object forKey:(id)key {
	
	if (![_values objectForKey:key]) {
		[_keys addObject:key];
	}
	[_values setObject:object forKey:key];
}

- (void)dealloc {
	
	[_values release];
	[_keys release];
	[super dealloc];
}

@end