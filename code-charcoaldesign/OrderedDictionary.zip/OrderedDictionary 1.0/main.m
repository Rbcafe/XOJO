#import <Foundation/Foundation.h>
#import "OrderedDictionary.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
    //create an ordered dictionary
	OrderedDictionary *odict = [OrderedDictionary dictionaryWithObjectsAndKeys:
								@"Object1", @"Key1",
								@"Object2", @"Key2",
								@"Object3", @"Key3",
								@"Object4", @"KeyDupe",
								@"Object5", @"KeyDupe",
								@"ObjectDupe", @"Key6",
								@"ObjectDupe", @"Key7",
								nil];
	
	//test overriden and dependent methods
	NSLog(@"copy: %@", [[[odict copy] autorelease] class]);
	NSLog(@"allKeys: %@", [odict allKeys]);
	NSLog(@"allKeysForObject: %@", [odict allKeysForObject:@"ObjectDupe"]);
	NSLog(@"allValues: %@", [odict allValues]);
	NSLog(@"count: %i", [odict count]);
	NSLog(@"description: %@", [odict description]);
	NSLog(@"descriptionInStringsFileFormat: %@", [odict descriptionInStringsFileFormat]);
	NSLog(@"descriptionWithLocale: %@", [odict descriptionWithLocale:[NSLocale currentLocale]]);
	NSLog(@"descriptionWithLocale:indent: %@", [odict descriptionWithLocale:[NSLocale currentLocale]
																	 indent:2]);
	NSLog(@"objectForKey: %@", [odict objectForKey:@"Key6"]); //ObjectDupe
	
	//test new methods
	NSLog(@"keyAtIndex: %@", [odict keyAtIndex:2]); //Key3
	NSLog(@"objectAtIndex: %@", [odict objectAtIndex:2]); //Object3
	
	//test fast enumeration
	NSString *result = @"";
	for (NSString *value in odict) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"Fast enumeration:%@", result);
	
	//test enumeration
	result = @"";
	for (NSString *key in [odict keyEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", key];
	}
	NSLog(@"keyEnumerator:%@", result);
	result = @"";
	for (NSString *key in [odict reverseKeyEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", key];
	}
	NSLog(@"reverseKeyEnumerator:%@", result);
	result = @"";
	for (NSString *value in [odict objectEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"objectEnumerator:%@", result);
	result = @"";
	for (NSString *value in [odict reverseObjectEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"reverseObjectEnumerator:%@", result);
	
	//create a mutable ordered dictionary
	MutableOrderedDictionary *modict = [MutableOrderedDictionary dictionaryWithDictionary:odict];
	
	//test methods
	[modict addEntriesFromDictionary:[OrderedDictionary dictionaryWithObjectsAndKeys:@"Object8", @"Key8", @"Object9", @"Key9", nil]];
	NSLog(@"addEntriesFromDictionary: %@", modict);
	[modict insertObject:@"Object1.5" forKey:@"Key1.5" atIndex:1];
	NSLog(@"insertObject:forKey:atIndex %@", modict);
	[modict removeObjectAtIndex:1];
	NSLog(@"removeObjectAtIndex: %@", modict);
	[modict removeObjectForKey:@"Key2"];
	NSLog(@"removeObjectForKey: %@", modict);
	[modict removeObjectsForKeys:[NSArray arrayWithObjects:@"Key3", @"KeyDupe", nil]];
	NSLog(@"removeObjectsForKeys: %@", modict);
	[modict removeAllObjects];
	NSLog(@"removeAllObjects: %@", modict);
	[modict setDictionary:[OrderedDictionary dictionaryWithObjectsAndKeys:@"Object2", @"Key2", @"Object3", @"Key3", nil]];
	NSLog(@"setDictionary: %@", modict);
	[modict setObject:@"Object4" forKey:@"Key4"];
	NSLog(@"setObject:forKey: %@", modict);
	[modict setValue:nil forKey:@"Key4"];
	NSLog(@"setValue:forKey: %@", modict);
	
	//create ordered mutable dictionary
	OrderedMutableDictionary *omdict = [OrderedMutableDictionary dictionaryWithObjectsAndKeys:
										@"Object1", @"Key1",
										@"Object2", @"Key2",
										@"Object3", @"Key3",
										@"Object4", @"KeyDupe",
										@"Object5", @"KeyDupe",
										@"ObjectDupe", @"Key6",
										@"ObjectDupe", @"Key7",
										nil];
	
	//test overriden and dependent methods
	NSLog(@"copy: %@", [[[omdict copy] autorelease] class]);
	NSLog(@"allKeys: %@", [omdict allKeys]);
	NSLog(@"allKeysForObject: %@", [omdict allKeysForObject:@"ObjectDupe"]);
	NSLog(@"allValues: %@", [omdict allValues]);
	NSLog(@"count: %i", [omdict count]);
	NSLog(@"description: %@", [omdict description]);
	NSLog(@"descriptionInStringsFileFormat: %@", [omdict descriptionInStringsFileFormat]);
	NSLog(@"descriptionWithLocale: %@", [omdict descriptionWithLocale:[NSLocale currentLocale]]);
	NSLog(@"descriptionWithLocale:indent: %@", [omdict descriptionWithLocale:[NSLocale currentLocale]
																	  indent:2]);
	NSLog(@"objectForKey: %@", [omdict objectForKey:@"Key6"]); //ObjectDupe
	
	//test new methods
	NSLog(@"keyAtIndex: %@", [omdict keyAtIndex:2]); //Key3
	NSLog(@"objectAtIndex: %@", [omdict objectAtIndex:2]); //Object3
	
	//test fast enumeration
	result = @"";
	for (NSString *value in omdict) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"Fast enumeration:%@", result);
	
	//test enumeration
	result = @"";
	for (NSString *key in [odict keyEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", key];
	}
	NSLog(@"keyEnumerator:%@", result);
	result = @"";
	for (NSString *key in [odict reverseKeyEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", key];
	}
	NSLog(@"reverseKeyEnumerator:%@", result);
	result = @"";
	for (NSString *value in [odict objectEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"objectEnumerator:%@", result);
	result = @"";
	for (NSString *value in [odict reverseObjectEnumerator]) {
		result = [result stringByAppendingFormat:@" %@", value];
	}
	NSLog(@"reverseObjectEnumerator:%@", result);
	
	//test methods
	[omdict addEntriesFromDictionary:[OrderedDictionary dictionaryWithObjectsAndKeys:@"Object8", @"Key8", @"Object9", @"Key9", nil]];
	NSLog(@"addEntriesFromDictionary: %@", omdict);
	[omdict insertObject:@"Object1.5" forKey:@"Key1.5" atIndex:1];
	NSLog(@"insertObject:forKey:atIndex %@", omdict);
	[omdict removeObjectAtIndex:1];
	NSLog(@"removeObjectAtIndex: %@", omdict);
	[omdict removeObjectForKey:@"Key2"];
	NSLog(@"removeObjectForKey: %@", omdict);
	[omdict removeObjectsForKeys:[NSArray arrayWithObjects:@"Key3", @"KeyDupe", nil]];
	NSLog(@"removeObjectsForKeys: %@", omdict);
	[omdict removeAllObjects];
	NSLog(@"removeAllObjects: %@", omdict);
	[omdict setDictionary:[OrderedDictionary dictionaryWithObjectsAndKeys:@"Object2", @"Key2", @"Object3", @"Key3", nil]];
	NSLog(@"setDictionary: %@", omdict);
	[omdict setObject:@"Object4" forKey:@"Key4"];
	NSLog(@"setObject:forKey: %@", omdict);
	[omdict setValue:nil forKey:@"Key4"];
	NSLog(@"setValue:forKey: %@", omdict);
	
    [pool drain];
    return 0;
}
