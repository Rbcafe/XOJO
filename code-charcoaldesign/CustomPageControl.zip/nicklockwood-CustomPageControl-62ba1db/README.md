CustomPageControl has been renamed to FXPageControl.

Get it here: https://github.com/nicklockwood/FXPageControl