//
//  SwiftExample-Bridging-Header.h
//  SwiftExample
//
//  Created by Nick Lockwood on 30/07/2014.
//  Copyright (c) 2014 Charcoal Design. All rights reserved.
//

#import "iCarousel.h"
