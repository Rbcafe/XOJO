//mac-specific constants
Blocks.CONSTANTS.MANIFEST = 'mac.manifest';
Blocks.CONSTANTS.PAUSE_CORNER = 0;
Blocks.CONSTANTS.DEMO_MODE_DELAY_AFTER_GAME = false;
Blocks.CONSTANTS.DEMO_MODE_ALLOWS_DIFFICULTY = false;
Blocks.CONSTANTS.DEMO_MODE_LIMITS_LEVELS = false;
Blocks.CONSTANTS.UNDO_CALLBACK_ENABLED = true;
Blocks.CONSTANTS.MOBILE_DEVICE = false;
Blocks.CONSTANTS.DESKTOP_DEVICE = true;
Blocks.CONSTANTS.MAC_APP_STORE_LINK = 'macappstore://itunes.apple.com/app/id412363063';
Blocks.CONSTANTS.ITUNES_LINK = Blocks.CONSTANTS.MAC_APP_STORE_LINK;

//larger sizes
Blocks.LARGE_CONSTANTS = {
	BLOCK_WIDTH: 68,
	BLOCK_HEIGHT: 66,
	POINTS_DISTANCE: 200
}

//smaller sizes
Blocks.SMALL_CONSTANTS = {};
for (i in Blocks.LARGE_CONSTANTS) {
	Blocks.SMALL_CONSTANTS[i] = Blocks.CONSTANTS[i];
}

//resizing function
Blocks.setLarge = function(large) {
	Blocks.CONSTANTS.WIDESCREEN = large;
	$('#large-size').attr('checked', large? 'checked': '');
	if (large) {
		$('body').addClass('large');
		var constants = Blocks.LARGE_CONSTANTS;
	} else {
		$('body').removeClass('large');
		var constants = Blocks.SMALL_CONSTANTS;
	}
	for (i in constants) {
		Blocks.CONSTANTS[i] = constants[i];
	}
	Blocks.refresh();
}

//set fullscreen
Blocks.setFullScreen = function(fullScreen) {
	Blocks.CONSTANTS.FULLSCREEN = fullScreen;
	$('#full-screen').attr('checked', fullScreen? 'checked': '');
}