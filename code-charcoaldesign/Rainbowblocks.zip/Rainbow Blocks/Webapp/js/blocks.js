var Blocks = new function() {
	
	//compatibility
	var VERSION = 1.1;
	
	//game constants
	var POINTS_PER_BLOCK = 5;
	var STARTING_POINT_TARGET = 750;
	var POINT_INCREMENT = 750;
	var STARTING_MULTIPLIER = 1;
	var MULTIPLIER_INCREMENT = 2;
	var BONUS_START_PERCENT = 86;
	var BONUS_START_AMOUNT = 25;
	var BONUS_MULTIPLIER_INCREMENT = 2;
	var MIN_SPECIALS = 2;
	var MAX_SPECIALS = 4;
	var HIGH_SCORE_COUNT = 10;
	var DEFAULT_NAME = 'Anonymous';
	var TOP_LEFT = 1;
	var TOP_RIGHT = 2;
	var BOTTOM_RIGHT = 3;
	var BOTTOM_LEFT = 4;
	var DEMO_LEVEL_LIMIT = 6;
	var UNDO_LIMIT = 3;
	var EASY = 1;
	var NORMAL = 2;
	var HARD = 3;
	var DIFFICULTY_TITLES = {
		1: 'Easy',
		2: 'Normal',
		3: 'Hard'
	}
	
	//configuration constants
	var CONSTANTS = {
		STAGE_WIDTH: 14,
		STAGE_HEIGHT: 9,
		BLOCK_WIDTH: 34,
		BLOCK_HEIGHT: 33,
		MANIFEST: 'iphone.manifest',
		PAUSE_CORNER: TOP_RIGHT,
		POINTS_DISTANCE: 100,
		GAME_CENTER: false,
		GAME_CENTER_ALIAS: null,
		DEBUG_MODE: false,
		DEMO_MODE: false,
		DEMO_MODE_DELAY_AFTER_GAME: true,
		DEMO_MODE_ALLOWS_DIFFICULTY: true,
		DEMO_MODE_LIMITS_LEVELS: true,
		UNDO_CALLBACK_ENABLED: false,
		SOUND_ENABLED: true,
		MUSIC_ENABLED: true,
		SHAKE_TO_UNDO: false,
		THEME: 0,
		MOBILE_DEVICE: true,
		DESKTOP_DEVICE: false,
		NATIVE_APP: true,
		WIDESCREEN: false,
		FULLSCREEN: false,
		IOS_APP_STORE_LINK: 'http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=355313284&mt=8',
		MAC_APP_STORE_LINK: 'http://itunes.apple.com/app/id412363063?mt=12&ls=1',
		ITUNES_LINK: 'http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=355313284&mt=8'
	}
	
	//block types
	var SPECIAL = 'special';
	var BLOCKS = [
		'block1',
		'block2',
		'block3',
		'block4',
		'block5'
	];
	
	//sound
	var TITLE_TRACK = 'title-track';
    var GAME_OVER_TRACK = 'game-over';
	var BLOCK_CLEAR_SOUND = 'block-clear';
	var BLOCK_SLIDE_SOUND = 'block-slide';
	var SPECIAL_BLOCK_SOUND = 'special-block';
	var GAME_START_SOUND = 'game-start';
	var PAUSE_SOUND = 'game-start';
	var HIGH_SCORE_SOUND = 'high-score';
	var UNDO_SOUND = 'undo';
	var LEVEL_COMPLETE_SOUND = 'level-complete';
	var BUTTON_SOUND = 'button-click';
	
	//seeded random number generator
	var Random = new function() {
	
		//initialise seed to current time
		this.seed = new Date().getTime();
		
		//get next number in sequence
		this.next = function() {
			this.seed = (this.seed*9301+49297) % 233280;
			return this.seed / (233280.0);
		}
		
		//get integer in range
		this.inRange = function(from, to) {
			return Math.floor(this.next() * (to - from)) + from;
		}
	}
	
	//get a random type
	function randomType() {
		return BLOCKS[Random.inRange(0, BLOCKS.length)];
	}

	//block class
	var Block = function(_x, _y, _type, _id) {
		
		//private properties
		var element = null;
		var type = _type;
		var x = _x;
		var y = _y;
		var id = _id || uniqueId();
		
		//methods
		this.randomise = function(callback) {
			this.setType(randomType(), callback);
			return this;
		}
		this.refresh = function() {
			element.css({
				left: x*CONSTANTS.BLOCK_WIDTH,
				top: y*CONSTANTS.BLOCK_HEIGHT
			});
		}
		this.moveTo = function(_x, _y, callback) {
			$.iQuery.enable(false);
			var css = {};
			if (x != _x) {
				x = _x;
				css.left = x*CONSTANTS.BLOCK_WIDTH;
			}
			if (y != _y) {
				y = _y;
				css.top = y*CONSTANTS.BLOCK_HEIGHT;
			}
			if (element) {
				if (typeof callback === 'function') {
					element.animate(css, callback);
				} else if (typeof callback !== 'undefined' && callback) {
					element.animate(css);
				} else {
					element.css(css);
				}
			} else if (typeof callback === 'function') {
				callback();
			}
			$.iQuery.enable(true);
			return this;
		}
		this.hasElement = function() {
			return (element)? true: false;
		}
		this.getElement = function(dontCreate) {
			if (!element && !dontCreate) {
				if (id) {
					element = $('#' + id);
				} else {
					//create element
					id = uniqueId();
					element = $(this.html());
				}
			}
			return element;
		}
		this.setType = function(_type, callback) {
			$.iQuery.enable(false);
			var oldType = type;
			type = _type;
			if (element) {			
				var parent = element.parent();
				if (typeof callback != 'undefined' && callback && parent.length) {
					callback = (typeof callback === 'function')? callback: function() {};
					if (!element.is(':visible')) {
						element.removeClass(oldType).addClass(type).fadeIn(callback);
					} else if (!element.hasClass(type)) {
						var oldElement = element;
						element = null;
						id = null;
						parent.append(this.getElement().hide().fadeIn(function () {
							oldElement.remove();
							callback();
						}));
					}
					$.iQuery.enable(true);
					return this;
				} else {
					element.removeClass(oldType).addClass(type)
					if (!element.is(':visible')) {
						element.show();
					}
				}
			}
			if (typeof callback === 'function') {
				callback();
			}
			$.iQuery.enable(true);
			return this;
		}
		this.getType = function() {
			return type;
		}
		this.getX = function() {
			return x;
		}
		this.getY = function() {
			return y;
		}
		this.getId = function() {
			return id;
		}
		this.setId = function(_id) {
			id = _id;
			element = null;
		}
		this.remove = function(callback) {
			$.iQuery.enable(false);
			if (element) {
				if (typeof callback !== 'unefined' && callback) {
					callback = (typeof callback === 'function')? callback: function() {};
					element.css('z-index', 1).fadeOut(function() {
						$(this).css('z-index', 'inherit');
						callback();
					});
				} else {
					element.hide();
				}
			} else if (typeof callback === 'function') {
				callback();
			}
			$.iQuery.enable(true);
			return this;
		}
		this.html = function(hidden) {
			var style = 'left:' + x*CONSTANTS.BLOCK_WIDTH + 'px;top:' + y*CONSTANTS.BLOCK_HEIGHT + 'px;';
			return '<div class="block ' + type + '" id="' + id + '" style="' + style + '"></div>';
		}
		
		//set type
		if (typeof _type === 'undefined') {
			this.randomise();
		}
	}
	
	//stage
	var Stage = function(_container, _touchEvent) {
		
		//private properties
		var blocks = [];
		var container = $(_container);
		var touchEvent = _touchEvent;

		var setBlocks = function(allBlocks) {
			var html = '';
			for (var i = 0; i < allBlocks.length; i++) {
				html += allBlocks[i].html();
			}
			container.html(html);
			for (var i = 0; i < allBlocks.length; i++) {
				allBlocks[i].getElement();
			}
		}
		
		//methods
		this.save = function() {
			var data = [];
			for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
				data.push([]);
				for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
					if (blocks[y].length > x) {
						data[y].push((blocks[y][x])? blocks[y][x].getType(): null);
					} else {
						data[y].push(null);
					}
				}
			}
			return data;
		}
		this.load = function(data) {
			//load blocks
			try {
				if (data.length == CONSTANTS.STAGE_HEIGHT) {
					var allBlocks = [];
					for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
						blocks[y] = [];
						if (data[y].length == CONSTANTS.STAGE_WIDTH) {
							for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
								if (data[y][x]) {
									var block = new Block(x, y, data[y][x]);
									blocks[y].push(block);
									allBlocks.push(block);
								} else {
									blocks[y].push(null);
								}
							}
						} else {
							this.reset(false);
							return false;
						}
					}
					//render blocks
					setBlocks(allBlocks);
					return true;
				}
				this.reset(false);
				return false;
			} catch (e) {
				this.reset(false);
				return false;
			}
		}
		this.refresh = function() {
			for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
				for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
					var block = blocks[y][x];
					if (block) {
						block.refresh();
					}
				}
			}
		}
		this.reset = function() {
			var types = {};
			blocks = [];
			//set regular blocks
			for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
				blocks[y] = [];
				for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
					types[y + '|' + x] = randomType();
				}
			}
			//add specials
			for (var i = Random.inRange(MIN_SPECIALS, MAX_SPECIALS + 1); i > 0; i--) {
				var y = Random.inRange(0, CONSTANTS.STAGE_HEIGHT);
				var x = Random.inRange(0, CONSTANTS.STAGE_WIDTH);
				var id = y + '|' + x;
				if (types[id] != SPECIAL) {
					types[id] = SPECIAL;
				} else {
					i++;
				}
			}
			//render blocks
			var allBlocks = [];
			for (id in types) {
				var yx = id.split('|');
				var y = yx[0];
				var x = yx[1];
				var block = new Block(x, y, types[id]);
				allBlocks.push(block);
				blocks[y][x] = block;
			}
			setBlocks(allBlocks);
		}
		this.getBlock = function(x, y) {
			return blocks[y][x];
		}
		this.moveBlock = function(fromX, fromY, toX, toY, callback) {		
			var block = blocks[fromY][fromX];
			if (block) {
				blocks[fromY][fromX] = null;
				blocks[toY][toX] = block.moveTo(toX, toY, callback);
			} else if (typeof callback === 'function') {
				callback();
			}
		}
		this.getCorner = function(corner) {
            if (corner == TOP_LEFT) {
				return blocks[0][0];
			} else if (corner == BOTTOM_LEFT) {
				return blocks[CONSTANTS.STAGE_HEIGHT - 1][0];
			} else if (corner == BOTTOM_RIGHT) {
				return blocks[CONSTANTS.STAGE_HEIGHT - 1][CONSTANTS.STAGE_WIDTH - 1];
			} else { //top right
				return blocks[0][CONSTANTS.STAGE_WIDTH - 1];
			}
		}
		this.randomiseBlocks = function(pivotx, pivoty, _callback) {		
			
			//hack to prevent phantom rainbow block bug
			if (blocks[pivoty][pivotx].getElement(true) == null) {
				_callback();
				return;
			}
			if (blocks[pivoty][pivotx].getElement()[0] != $('#' + blocks[pivoty][pivotx].getId())[0]) {
				_callback();
				return;
			}
			if (!blocks[pivoty][pivotx].getElement().is(':visible')) {
				_callback();
				return;
			}
			if (blocks[pivoty][pivotx].getType() != SPECIAL) {
				_callback();
				return;
			}
			
			var animating = 0;
			var callback = (typeof _callback === 'function')? function() {
				animating --;
				if (animating === 0) {
					_callback();
				}
			}: undefined;
			//new block types
			var types = {};
			//specials
			var specials = 0;
			//randomise blocks
			for (var y = Math.max(0, pivoty - 2); y < Math.min(CONSTANTS.STAGE_HEIGHT, pivoty + 3); y++) {
				for (var x = Math.max(0, pivotx - 2); x < Math.min(CONSTANTS.STAGE_WIDTH, pivotx + 3); x++) {
					if (x != pivotx | y != pivoty) {
						var block = blocks[y][x];
						if (block) {
							if (block.getType() == SPECIAL) {
								specials++;
							}
							types[y + '|' + x] = randomType();;
						}
					}
				}
			}
			//restore specials
			for (var i = 0 ; i < specials; i++) {
				var x = pivotx, y = pivoty;
				while (!blocks[y][x] || (x == pivotx && y == pivoty) || types[y + '|' + x] == SPECIAL) {
					x = Math.min(CONSTANTS.STAGE_WIDTH - 1, Math.max(0, pivotx + Random.inRange(-2, 3)));
					y = Math.min(CONSTANTS.STAGE_HEIGHT - 1, Math.max(0, pivoty + Random.inRange(-2, 3)));
				}
				types[y + '|' + x] = SPECIAL;
			}
			//calculate weights
			var weights = {};
			for (var i = 0 ; i < BLOCKS.length; i++) {
				weights[BLOCKS[i]] = 0;
			}
			var highest = randomType();
			var highestWeight = 0;
			for (var y = Math.max(0, pivoty - 1); y < Math.min(CONSTANTS.STAGE_HEIGHT, pivoty + 2); y++) {
				for (var x = Math.max(0, pivotx - 1); x < Math.min(CONSTANTS.STAGE_WIDTH, pivotx + 2); x++) {
					if (x != pivotx | y != pivoty) {
						var type = types[y + '|' + x];
						if (type != SPECIAL) {
							weights[type]++;
							if ((x == pivotx || y == pivoty) && weights[type] > highestWeight) {
								highest = type;
								highestWeight = weights[type];
							}
						}
					}
				}
			}
			//set pivot value to best neighbour
			types[pivoty + '|' + pivotx] = highest;
			//animate blocks
			for (id in types) {
				var yx = id.split('|');
				var y = yx[0];
				var x = yx[1];
				animating ++;
				blocks[y][x].setType(types[id], callback);
			}			
		}
		this.findNeighbours = function(x, y) {
			var _findNeighbours = function(x, y, block, checked, affected) {
				var _block = blocks[y][x];
				var id = y + '|' + x;
				if (!checked[id]) {
					checked[id] = true;
					if (block && _block && block.getType() == _block.getType()) {
						affected.push(_block);
						if (x > 0) _findNeighbours(x-1, y, block, checked, affected);
						if (x < CONSTANTS.STAGE_WIDTH - 1) _findNeighbours(x+1, y, block, checked, affected);
						if (y > 0) _findNeighbours(x, y-1, block, checked, affected);
						if (y < CONSTANTS.STAGE_HEIGHT - 1) _findNeighbours(x, y+1, block, checked, affected);
					}
				}
				return affected;
			}
			return _findNeighbours(x, y, blocks[y][x], [], []);
		}
		this.remove = function(x, y, callback) {
			var block = blocks[y][x];
			if (block) {
				blocks[y][x] = null;
				block.remove(callback);
			}
		}
		this.shiftDown = function(callback) {		
			var falling = 0;
			callback = (typeof callback === 'function')? callback: function() {};
			for (x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
				var shift = 0;
				for (y = CONSTANTS.STAGE_HEIGHT - 1; y >= 0; y--) {
					if (!blocks[y][x]) {
						shift++;
					} else if (shift > 0) {
						falling++;
						stage.moveBlock(x, y, x, y + shift, function() {
							falling--;
							if (falling == 0) {	
								callback();
							}
						});
					}
				}
			}
			if (falling == 0) {
				callback();
				return false;
			}
			return true;
		}
		this.shiftRight = function(callback) {
			var sliding = 0;
			var shift = 0;
			callback = (typeof callback === 'function')? callback: function() {};
			for (x = CONSTANTS.STAGE_WIDTH - 1; x >= 0; x--) {
				var shiftNeeded = true;
				for (y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
					if (blocks[y][x]) {
						shiftNeeded = false;
						break;
					}
				}
				if (shiftNeeded) {
					shift++;
				} else if (shift > 0) {
					for (y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
						if (blocks[y][x]) {
							sliding++;
							stage.moveBlock(x, y, x + shift, y, function() {
								sliding--;
								if (sliding == 0) {
									callback();
								}
							});
						}
					}
				}
			}
			if (sliding == 0) {
				callback();
				return false;
			}
			return true;
		}
		this.levelComplete = function() {
			for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
				for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
					var block = blocks[y][x];
					if (block && (block.getType() == SPECIAL || this.findNeighbours(x, y).length > 1)) {
						return false;
					}
				}
			}
			return true;
		}
		this.percentComplete = function() {
			var total = CONSTANTS.STAGE_WIDTH * CONSTANTS.STAGE_HEIGHT;
			var complete = 0;
			for (var y = 0; y < CONSTANTS.STAGE_HEIGHT; y++) {
				for (var x = 0; x < CONSTANTS.STAGE_WIDTH; x++) {
					if (!blocks[y][x]) {
						complete++;
					}
				}
			}
			return Math.round(complete/total * 100);
		}
		this.showPoints = function(x, y, _points) {	
			$.iQuery.enable(false);
			var style = 'left:' + x*CONSTANTS.BLOCK_WIDTH + 'px;top:' + y*CONSTANTS.BLOCK_HEIGHT + 'px';
			var id = uniqueId();
			var points = $('<div class="points" id="' +id + '" style="' + style + '">' + _points + '</div>');
			container.append(points);
			points.animate({
				top: y*CONSTANTS.BLOCK_HEIGHT - CONSTANTS.POINTS_DISTANCE,
				left: x*CONSTANTS.BLOCK_WIDTH,
				opacity: 0
			}, 1000, function() {
				points.remove();
			});
			$.iQuery.enable(true);
		}
		
		//initialise blocks
		this.reset(false);

		//bind touch event
		container.mousedown(function(e) {
			var offsetX = container[0].offsetLeft;
			var offsetY = container[0].offsetTop - $('#hud')[0].offsetTop;
			var blockWidth = container.width() / CONSTANTS.STAGE_WIDTH;
			var blockHeight = container.height() / CONSTANTS.STAGE_HEIGHT;
			var x = Math.floor((e.pageX - offsetX)/blockWidth);
			var y = Math.floor((e.pageY - offsetY)/blockHeight);
			touchEvent(blocks[y][x], x, y);
		});
	}
	
	//score and goals
	var HUD = function () {

		//methods
		this.refresh = function() {
			this.refreshScore();
			$('#level span').text(level);
			$('#target span').eq(0).text(targetScore);
		}
		this.refreshScore = function() {
			$('#score span').text(score);
		}
	}
	
	//high scores
	var Scores = function (difficulty) {
		
		//private properties
		var difficulty = difficulty;
		var scores = null;
		var lastHighScore = -1;
		
		//methods
		this.load = function(data) {
			if (data) {
				scores = data;
				return true;
			}
			return false;
		}
		this.save = function() {
			return scores;
		}
		this.reset = function() {
			scores = {names:[],scores:[],levels:[]};
			for (var i = 0; i < HIGH_SCORE_COUNT; i++) {
				scores.names.push('');
				scores.scores.push(0);
				scores.levels.push('-');
			}
		}
		this.refresh = function() {
			var html = '';
			for (var i = 0; i < scores.scores.length; i++) {
				var level = (scores.levels && scores.levels[i])? scores.levels[i]: '-';
				html += '<li' + ((i == lastHighScore)? ' class="hilight"': '') + '>' + scores.names[i]
					  + '<span>' + scores.scores[i] + '<span>' + level + '</span></span></li>';
			}
			$('#scores ol').html(html);
			$('#scores h1 span').html(' (' + DIFFICULTY_TITLES[difficulty] + ')');
			$('#scores #difficulty').html('Show ' + DIFFICULTY_TITLES[(difficulty == HARD)? EASY: difficulty + 1]);
		}
		this.isHighScore = function(score) {
			return (score > scores.scores[HIGH_SCORE_COUNT - 1]);
		}
		this.addHighScore = function(name, score, level) {
			for (var i = 0; i < HIGH_SCORE_COUNT; i++) {
				if (score > scores.scores[i]) {
					//slide scores down
					if (!scores.levels) {
						scores.levels = [];
					}
					for (var j = HIGH_SCORE_COUNT - 1; j > i; j--) {
						scores.scores[j] = scores.scores[j - 1];
						scores.names[j] = scores.names[j - 1];
						scores.levels[j] = (scores.levels[j - 1])? scores.levels[j - 1]: '-';
					}
					//set score
					scores.scores[i] = score;
					scores.names[i] = name;
					scores.levels[i] = level;
					//return index
					lastHighScore = i;
					return i;
				} 
			}
			return -1
		}
		this.show = function(callback, playAgainButton) {
			if (!!playAgainButton) {
				$('#play-again').show();
				$('#difficulty').hide();
			} else {
				$('#play-again').hide();
				$('#difficulty').show();
			}
			if (typeof callback != 'undefined' && callback) {
				callback = (typeof callback === 'function')? callback: function() {};
				$('#scores').fadeIn(callback);
			} else {
				$('#scores').show();
			}
		}
		this.hide = function(callback) {
			lastHighScore = -1;
			if (typeof callback != 'undefined' && callback) {
				callback = (typeof callback === 'function')? callback: function() {};
				$('#scores').fadeOut(function() {
					$(this).find('.hilight').removeClass('hilight');
					callback();
				});
			} else {
				$('#scores').hide().find('.hilight').removeClass('hilight');
			}
		}
		
		//initialise scores
		this.reset();
	}
	
	//queued actions
	var actionQueue = [];
	/*function queueAction(fn) {
		if (actionQueue.length == 0) {
			actionQueue.push(function() {});
			actionQueue.push(fn);
			function nextAction() {
				actionQueue.shift();
				if (actionQueue.length > 0) {
					actionQueue[0]();
					setTimeout(nextAction, 100);
				}
			}
			setTimeout(nextAction, 50);
		}
		actionQueue.push(fn);
	}*/
	
	function queueAction(fn) {
		if (actionQueue.length == 0) {
			var fn = fn;
			setTimeout(function() {
				fn();
				function nextAction() {
					actionQueue.shift();
					if (actionQueue.length > 0) {
						actionQueue[0]();
						setTimeout(nextAction, 100);
					}
				}
				setTimeout(nextAction, 100);
			}, 50);
		}
		actionQueue.push(fn);
	}
	
	//open url
	function openURL(url) {
		var url = url;
		queueAction(function() {
			window.top.location = url;
		});
	}
	
	//audio
	var Audio = function() {
		this.switchTrack = function() {
			if (CONSTANTS.NATIVE_APP && CONSTANTS.MUSIC_ENABLED) {
				openURL('http://audio.rainbowblocks/switchTrack');
			}
		}
        this.playSound = function(name) {
			if (CONSTANTS.NATIVE_APP && CONSTANTS.SOUND_ENABLED) {
				openURL('http://audio.rainbowblocks/playSound?name=' + encodeURIComponent(name));
			}
		}
		this.playSounds = function(names) {
			if (CONSTANTS.NATIVE_APP && CONSTANTS.SOUND_ENABLED) {
				openURL('http://audio.rainbowblocks/playSounds?names=' + encodeURIComponent(names.join(',')));
			}
		}
        this.playMusic = function(name,looping) {
			if (CONSTANTS.NATIVE_APP && CONSTANTS.MUSIC_ENABLED) {
				openURL( 'http://audio.rainbowblocks/playMusic?name=' + encodeURIComponent(name));
			}
		}
		this.stopMusic = function() {
			if (CONSTANTS.NATIVE_APP) {
				openURL('http://audio.rainbowblocks/stopMusic');
			}
		}
	}
	
	//button clicks
	if(navigator.userAgent.match(/iPhone|iPod|iPad|Android/i)) {
		$('.button').live('touchstart', function() {
			audio.playSound(BUTTON_SOUND);
		});
	} else {
		$('.button').live('mousedown', function() {
			audio.playSound(BUTTON_SOUND);
		});
	}
		
	//game state
	var initialised = false;
	var paused = false;
	var pausedModal = null;
	var level = 1;
	var score = 0;
	var scoreAtLevelStart = 0;
	var difficulty = NORMAL;
	var name = DEFAULT_NAME;
	var targetScore = STARTING_POINT_TARGET;
	var hud = new HUD();
	var stage = null;
	var scores = null;
	var undoSeed = 0;
	var undoState = null;
	var undoScore = 0;
	var undoLevel = 0;
	var undosRemaining = UNDO_LIMIT;
	var animating = false;
	var startedAnimating = null;
	var animationTimeout = null;
	var levelComplete = false;
	var audio = new Audio();
	
	//preload images from manifest
	var images = [];
	$.get(CONSTANTS.MANIFEST, function(text) {
		$.each(text.split(/\s+/), function() {
			if (/\.(png|gif|jpeg|jpg)$/.test(this) && !/^#/.test(this)) {
				var image = new Image(1,1); 
				image.src = this;
				images.push(image);
			}
		});
	});
	
	//get unique id
	var nextId = 0;
	function uniqueId() {
		return 'rb' + nextId ++;
	}
	
	//check if game is running
	function gameRunning() {
		return initialised && !$('#menu').is(':visible') || score > 0;
	}
	
	//refresh level html
	function refreshHTML() {
		hud.refresh();
		updatePause();
	}
	
	//reset game
	function resetGame() {
		undosRemaining = UNDO_LIMIT;
		undoState = null;
		undoScore = 0;
		undoLevel = 0;
		levelComplete = false;
		level = 1;
		score = 0;
		scoreAtLevelStart = 0;
		targetScore = levelCompletionTarget(level);
		if (CONSTANTS.UNDO_CALLBACK_ENABLED) {
			openURL('http://undo.rainbowblocks/disable?remaining=' + undosRemaining);
		}
	}
	
	//increment level
	function nextLevel() {
		audio.switchTrack();
		//basic check to reduce skipping
		if (score > scoreAtLevelStart) {
			level++;
			scoreAtLevelStart = score;
		}
		targetScore = levelCompletionTarget(level);
		queueAction(function() {
			stage.reset();
		});
		queueAction(function() {
			refreshHTML();
			levelComplete = false;
			updatePause();
		});
	}
	
	//undo
	function canUndo() {
		return undoState != null && undosRemaining != 0;
	}
	function undo() {
		if (canUndo()) {
			Random.seed = undoSeed;
			audio.playSound(UNDO_SOUND);
			queueAction(function() {
				stage.load(undoState);
				score = undoScore;
				level = undoLevel;
				scoreAtLevelStart = score - 1; //we don't record this
				levelComplete = false;
				targetScore = levelCompletionTarget(level);
				undoSeed = 0;
				undoState = null;
				undoScore = 0;
				undoLevel = 0;
				undosRemaining --;
			});
			queueAction(function() {
				refreshHTML();
			});
			if (CONSTANTS.UNDO_CALLBACK_ENABLED) {
				openURL('http://undo.rainbowblocks/disable?remaining=' + undosRemaining);
			}
		}
	}

	//show/hide pause button
	function updatePause() {
		$.iQuery.enable(false);
		var pause = $('#pause');
		if (pause.length) {
			var block = stage.getCorner(CONSTANTS.PAUSE_CORNER);
			if (block && block.getType() == SPECIAL) {
				pause.fadeOut();
			} else {
				pause.fadeIn();
			}
		}
		$.iQuery.enable(true);
	}
	
	//click function
	function blockClicked(block, x, y) {
		
		var _startAnimating = function() {
			animating = true;
			startedAnimating = new Date();
			animationTimeout = setTimeout(_update, 850);
		}
		
		var _update = function() {
			clearTimeout(animationTimeout);
			animating = false;
			updatePause();
			checkIfLevelEnded();
		}
		
		//time out animation lock in case of glitches
		if (animating && (new Date()) - startedAnimating > 800) {
			_update();
		}
		
		//don't support interaction while animating
		if (animating || levelComplete) {
			return false;
		}
		
		if (block) {
			if (block.getType() == SPECIAL) {
				//handle special
				
				audio.playSound(SPECIAL_BLOCK_SOUND);
				
				//preserve state for undo
				undoSeed = Random.seed;
				undoState = stage.save();
				undoScore = score;
				undoLevel = level;

				//randomise surrounding blocks
				_startAnimating();
				stage.randomiseBlocks(x, y, _update);
				
				//update undo
				if (CONSTANTS.UNDO_CALLBACK_ENABLED) {
					if (canUndo()) {
						openURL('http://undo.rainbowblocks/enable?remaining=' + undosRemaining);
					} else {
						openURL('http://undo.rainbowblocks/disable?remaining=' + undosRemaining);
					}
				}
			
			} else {
				//handle normal
		
				//find all affected blocks
				var affected = stage.findNeighbours(x, y);
			
				if (affected.length > 1) {
					
					if (affected.length > 5) {
						audio.playSounds([BLOCK_CLEAR_SOUND, HIGH_SCORE_SOUND]);
					} else {
						audio.playSound(BLOCK_CLEAR_SOUND);
					}
					
					//preserve state for undo
					undoSeed = Random.seed;
					undoState = stage.save();
					undoScore = score;
					undoLevel = level;

					//update score
					var points = affected.length * affected.length * POINTS_PER_BLOCK;
					score += points;
					hud.refreshScore();
					
					//display points
					stage.showPoints(x, y, points);
					
					//remove from stage
					for (i = 0; i < affected.length; i++) {
						stage.remove(affected[i].getX(), affected[i].getY(), true);
					}
					
					//shift blocks
					_startAnimating();
					var shiftedDown = false;
					shiftedDown = stage.shiftDown(function() {
						var shiftedRight = stage.shiftRight(_update);
						if (shiftedDown && shiftedRight) {
							audio.playSound(BLOCK_SLIDE_SOUND);
						}
					});
					
					//update undo
					if (CONSTANTS.UNDO_CALLBACK_ENABLED) {
						if (canUndo()) {
							openURL('http://undo.rainbowblocks/enable?remaining=' + undosRemaining);
						} else {
							openURL('http://undo.rainbowblocks/disable?remaining=' + undosRemaining);
						}
					}
				}
			}
		}
		
		//cancel event
		return false;
	}
	
	//calculate
	function completionBonus(percentComplete) {
		var bonus = 0;
		var bonusMultiplier = 1;
		for (var i = BONUS_START_PERCENT; i <= percentComplete; i++) {
			bonus += BONUS_START_AMOUNT * bonusMultiplier;
			bonusMultiplier += BONUS_MULTIPLIER_INCREMENT;
		}
		return bonus;
	}
	
	//modals

	function showLevelComplete(completed, bonus) {
		audio.playSound(LEVEL_COMPLETE_SOUND);
        Modal.dialog(
			'Level ' + level + ' Complete\n\n' + 
			'Score: ' + score + '\n' +
			'Completed: ' + completed + '%\n' +
			'Bonus: ' + bonus, {
				'Continue': function() {
					this.close();
                    nextLevel();
				}
			}
		);
	}
	
	function showGameOver() {
		audio.stopMusic();
		audio.playSound(GAME_OVER_TRACK);
		var text = 'Game Over\n\nYou needed ' + targetScore + ' points to complete the level. You scored ' + score + '. Better luck next time!';
		if (scores[difficulty].isHighScore(score)) {
			Modal.dialog(text, {
				'High Score': function() {
					showHighScore();
					this.close();
				}
			});
		} else {
			Modal.dialog(text, {
				'Play Again': function() {
					audio.switchTrack();
					resetGame();
					stage.reset();
					refreshHTML();
					this.close();
				},
				'Quit': function() {
					scores[difficulty].refresh();
					scores[difficulty].show(true);
					this.close();
				}
			});
		}
	}
	
	function showDemoGameOver(hitLimit) {
		audio.stopMusic();
		audio.playSound(GAME_OVER_TRACK);
        var text = (!!hitLimit)?
            'Demo Limit Reached\n\nTo play past level ' + DEMO_LEVEL_LIMIT + ', please\nbuy the full version' :
            'Game Over\n\nYou needed ' + targetScore + ' points to complete the level. You scored ' + score + '. Better luck next time!'
		var modal = Modal.dialog(text, {
			'Buy Full Game':  function() {
				resetGame();
				modal.close();
				openURL(CONSTANTS.ITUNES_LINK);
				showMenu();
			}
		});
		if (CONSTANTS.DEMO_MODE_DELAY_AFTER_GAME) {
			var count = 5;
			function buttonText() {
				return 'Play Again' + ((count > 0)? ' (' + count + ')' : '');
			}
			modal.addButton(buttonText(), function() {}, true);
			var playAgainButton = modal.find('.button:last');
			var countdown = setInterval(function() {
				count--;
				playAgainButton.html(buttonText());
				if (count == 0) {
					clearInterval(countdown);
					playAgainButton.removeClass('disabled');
					playAgainButton.mousedown(function() {
						resetGame();
						modal.close();
						showMenu();
						return false;
					});
				}
			}, 1000);
		} else {
			modal.addButton('Play Again', function() {
				resetGame();
				stage.reset();
				refreshHTML();
				this.close();
			});
			modal.addButton('Quit', function() {
				resetGame();
				modal.close();
				showMenu();
			});
		}
	}
	
	function showHighScore(noGameCenter) {
		audio.playSound(HIGH_SCORE_SOUND);
		if (CONSTANTS.GAME_CENTER_ALIAS && !noGameCenter) {
			var submitted = false;
			Modal.dialog('High Score\n\nLogged in as ' + CONSTANTS.GAME_CENTER_ALIAS, {
				'Submit Score': function() {
					if (!submitted) {
						submitted = true;
						scores[difficulty].addHighScore(CONSTANTS.GAME_CENTER_ALIAS, score, level);
						scores[difficulty].refresh();
						openURL('http://gameCenter.rainbowblocks/submit?score=' + score +
							'&level=' + level + '&difficulty=' + DIFFICULTY_TITLES[difficulty].toLowerCase());
						resetGame();
					}
					scores[difficulty].show(true, true);
					this.close();
				},
				'That\'s Not Me': function() {
					showHighScore(true);
					this.close();
				},
				'Cancel': function() {
					scores[difficulty].refresh();
					resetGame();
					scores[difficulty].show(true, true);
					this.close();
				}
			});
		} else {
			var submitted = false;
			Modal.prompt('High Score\n\nPlease enter your name', {placeholder: name, maxlength: 30}, function(newName) {
				if (!submitted) {
					submitted = true;
					if (newName !== null) {
						name = newName.replace(/<[^>]*>/g, '') || name;
						scores[difficulty].addHighScore(name, score, level);
					}
					scores[difficulty].refresh();
					resetGame();
				}
				scores[difficulty].show(true, true);
				audio.playMusic(TITLE_TRACK);
			});
		}
	}
	
	//check if level complete
	function checkIfLevelEnded() {
		if (stage.levelComplete()) {
			var completed = stage.percentComplete();
			var bonus = completionBonus(completed);
			if (!levelComplete) {
				levelComplete = true;
				score += bonus;
			}
			if (!CONSTANTS.DEBUG_MODE && score >= targetScore) {
				if (CONSTANTS.DEMO_MODE && CONSTANTS.DEMO_MODE_LIMITS_LEVELS && level >= DEMO_LEVEL_LIMIT) {
				    showDemoGameOver(true);
				} else {
				    showLevelComplete(completed, bonus);
				}
			} else if (CONSTANTS.DEMO_MODE) {
				showDemoGameOver();
			} else {
				showGameOver();
			}
		}
	}
	
	//pause
	function pause(prompt) {
		if (gameRunning()) {
			if (!paused) {
				audio.playSound(PAUSE_SOUND);
				paused = true;
				if (typeof(prompt) == 'undefined' || prompt) {
					var modal = Modal.dialog('Paused', {
						'Resume': function() {
							setTimeout(resume, 100);
							modal.close();
						},
						'Instructions': function() {
							showInstructions(resume);
							modal.close();
						}
					});
					modal.addButton('Settings', function() {
						showSettings(resume);
						modal.close();
					});
					var undoButtonName = 'Undo';
					if (undosRemaining == 0) {
						undoButtonName = 'No Undos Left';
					} else if (!undoState) {
						undoButtonName = 'Can\'t Undo';
					} else if (UNDO_LIMIT > 0) {
						undoButtonName += ' (' + undosRemaining + ' Available)';
					}
					var undone = false;
					modal.addButton(undoButtonName, function() {
						if (!undone) {
							undone = true;
							undo();
							resume();
						}
						modal.close();
					}, !canUndo());
					modal.addButton('Quit', function() {
						if (!CONSTANTS.DESKTOP_DEVICE) {
							Modal.confirm('Really Quit?\n\nAre you sure you want to quit your game?', function() {
								resetGame();
								showMenu();
							}, function() {
								resume();
							});
							modal.close();
						} else {
							Modal.custom('', {
								'Exit To Menu': function() {
									resetGame();
									showMenu();
									this.close();
								},
								'Save &amp; Quit': function() {
									this.close();
									openURL('http://app.rainbowblocks/quit');
								},
								'Cancel': function() {
									this.close();
									setTimeout(resume, 100);
								}
							});
							modal.close();
						}
					});
					modal.bindKey('Resume', Modal.CANCEL);
					pausedModal = modal;
				}
			}
		}
	}
	
	//resume
	function resume(prompt) {
		if (gameRunning()) {
			if (paused) {
				paused = false;
				if (score > 0 && !!prompt) {
					Modal.confirm('Resume?\n\nWould you like to resume the previous game?', function() {
						checkIfLevelEnded();
					}, function() {
						resetGame();
						showMenu();
					});
				}
				if (pausedModal) {
					pausedModal.close();
					pausedModal = null;
				}
			}
		}
	}
	
	//set pause corner
	function setPauseCorner(corner) {
		$('#pause-select').val(corner);
		CONSTANTS.PAUSE_CORNER = corner;
		for (var i = 1; i < 5; i++) {
			switch(i) {
			case TOP_LEFT:
				var className = 'top-left';
				break;
			case TOP_RIGHT:
				var className = 'top-right';
				break;
			case BOTTOM_RIGHT:
				var className = 'bottom-right';
				break;
			case BOTTOM_LEFT:
				var className = 'bottom-left';
				break;
			}
			if (i == corner) {
				$('#pause').addClass(className);
			} else {
				$('#pause').removeClass(className);
			}
		}
		if (corner > 0) {
			$('#pause-button').hide();
		} else {
			$('#pause-button').show();
		}
		updatePause();
	}
	
	//set difficulty constants
	function setDifficulty(d) {
		difficulty = d;
		switch (difficulty) {
		case EASY:
			DEMO_LEVEL_LIMIT = 9;
			STARTING_POINT_TARGET = 450;
			STARTING_MULTIPLIER = 1;
			POINT_INCREMENT = 450;
			MIN_SPECIALS = 3;
			MAX_SPECIALS = 5;
			UNDO_LIMIT = -1;
			break;
		case NORMAL:
			DEMO_LEVEL_LIMIT = 6;
			STARTING_POINT_TARGET = 750;
			STARTING_MULTIPLIER = 1;
			POINT_INCREMENT = 750;
			MIN_SPECIALS = 2;
			MAX_SPECIALS = 4;
			UNDO_LIMIT = 3;
			break;
		case HARD:
			DEMO_LEVEL_LIMIT = 3;
			STARTING_POINT_TARGET = 3000;
			STARTING_MULTIPLIER = 5;
			POINT_INCREMENT = 750;
			MIN_SPECIALS = 2;
			MAX_SPECIALS = 3;
			UNDO_LIMIT = 1;
			break;
		}
	}
	
	//game center cancelled
	function gameCenterCancelled() {
		Modal.alert('Game Center Disabled\n\nIf you change your mind, you can enable Game Center in the settings.');
		setGameCenterAlias(null);
		openURL('http://gameCenter.rainbowblocks/disable');
	}
	
	//game center
	function requestEnableGameCenter() {
		var modal = Modal.dialog('Game Center\n\nEnable Game Center support for global high scores and achievements.', {
			'Enable': function() {
				modal.close();
				openURL('http://gameCenter.rainbowblocks/enable');
			},
			'No Thanks': function() {
				gameCenterCancelled();
				modal.close();
			}
		});
	}
	
	//level target
	function levelCompletionTarget(level, difficulty) {
		var targetScore = STARTING_POINT_TARGET;
		var multiplier = STARTING_MULTIPLIER;
		for (var i = 1; i < level; i++) {
			targetScore += POINT_INCREMENT * multiplier;
			multiplier += MULTIPLIER_INCREMENT;
		}
		return targetScore;
	}
	
	//start game
	function startGame(difficulty) {
		audio.playSound(GAME_START_SOUND);
		audio.switchTrack();
		setDifficulty(difficulty);
		resetGame();
		paused = false;
		stage.reset(false);
		refreshHTML();
		$.iQuery.enable(false);
		$('#menu').fadeOut();
		$.iQuery.enable(true);
	}
	
	//reset scores
	function resetScores() {
		scores[EASY] = new Scores(EASY);
		scores[NORMAL] = new Scores(NORMAL);
		scores[HARD] = new Scores(HARD);
		scores[difficulty].refresh();
	}
	
	//initialise
	function init() {
		
		//initialise difficulty
		setDifficulty(difficulty);
		
		//initialise stage
		if (!stage) {
			stage = new Stage($('#stage'), blockClicked);
		}
		
		//initialise scores
		if (!scores) {
			scores = {};
			scores[EASY] = new Scores(EASY);
			scores[NORMAL] = new Scores(NORMAL);
			scores[HARD] = new Scores(HARD);
		}
		scores[difficulty].refresh();
		
		//position pause
		setPauseCorner(CONSTANTS.PAUSE_CORNER);
		
		//initialise game events
		$('#pause,#pause-button').mousedown(pause);
		
		//pause with keyboard
		$(document).keydown(function(event) {
			if (!paused && event.which == 27) { //escape
				pause(true);
				return false;
			}
		});
		
		//prevent rubber banding
		$(document).bind('touchmove', function() {
			return false;
		});
		
		//widescreen
		CONSTANTS.WIDESCREEN = ($('body').width() > 480);
		
		//default screen
		$('#default').click(function() {
			$(this).fadeOut();
			return false;
		});
		
		//menu screen
		$('#new-game').click(function() {
			if (!CONSTANTS.DEMO_MODE || CONSTANTS.DEMO_MODE_ALLOWS_DIFFICULTY) {
				var modal = Modal.dialog('Select Difficulty', {
					'Easy': function() {
						modal.close();
						startGame(EASY);
					},
					'Normal':  function() {
						modal.close();
						startGame(NORMAL);
					},
					'Hard':  function() {
						modal.close();
						startGame(HARD);
					},
					'Cancel':  function() {
						modal.close();
					}
				});
				//bind return key to whatever the last played difficulty was
				modal.bindKey(DIFFICULTY_TITLES[difficulty], Modal.DEFAULT);
			} else {
				startGame(NORMAL);
			}
			return false;
		});
		$('#instructions').click(function() {
			showInstructions();
			return false;
		});
		$('#settings').click(function() {
			showSettings();
			return false;
		});
		$('#high-scores').click( function() {
			scores[difficulty].show(true);
			return false;
		});
		$('#buy-now').each(function() {
			CONSTANTS.DEMO_MODE = true;
			if (CONSTANTS.NATIVE_APP) {
				$(this).click(function() {
					openURL(CONSTANTS.ITUNES_LINK);
					return false;
				});
			} else {
				$(this).click(function() {
					Modal.dialog('Select Version\n\nRainbow Blocks is available for Mac and iPhone/iPad. Which version would you like to buy?', {
						'Mac Version': function() {
							openURL(CONSTANTS.MAC_APP_STORE_LINK);
							modal.close();
						},
						'iPhone Version': function() {
							openURL(CONSTANTS.IOS_APP_STORE_LINK);
							modal.close();
						},
					});
					return false;
				});
			}
		});
		$('#upgrade').each(function() {
			CONSTANTS.DEMO_MODE = true;
			$(this).click(function() {
				var message = '<h1>Upgrade to the full version of Rainbow Blocks</h1><ul>';
				if (CONSTANTS.DEMO_MODE_LIMITS_LEVELS) {
					message += '<li>No level limit - play as far as your skills will get you</li>';
				}
				if (!CONSTANTS.DEMO_MODE_ALLOWS_DIFFICULTY) {
					message += '<li>A choice of easy, normal and hard difficulty levels</li>';
				}
				message += '<li>Enter and save your high scores</li></ul>';
				var modal = Modal.custom(message);
				modal.addClass('wide');
				modal.addButton('Buy Now', function() {
					openURL(CONSTANTS.ITUNES_LINK);
					modal.close();
				});
				modal.addButton('No, Thanks', function() {
					modal.close();
				});
				return false;
			});
		});
		
		//scores screen
		$('#difficulty').click(function() {
			difficulty ++;
			if (difficulty > HARD) {
				difficulty = EASY;
			}
			setDifficulty(difficulty);
			scores[difficulty].refresh();
			return false;
		});
		$('#play-again').click(function() {
			startGame(difficulty);
			scores[difficulty].hide(true);
			return false;
		});
		$('#global-scores').click(function() {
			openURL('http://gameCenter.rainbowblocks/scores?difficulty=' + DIFFICULTY_TITLES[difficulty].toLowerCase());
			return false;
		});
		$('#close-scores').click(function() {
			$('#menu').attr('style', 'display:block'); //show menu
			scores[difficulty].hide(true);
			return false;
		});
		$('#clear-scores').click(function() {
			var modal = Modal.confirm('Clear High Scores?\n\nAre you sure you want to clear the <strong>' +
			DIFFICULTY_TITLES[difficulty].toLowerCase() + '</strong> high scores? You cannot undo this action.', function() {
				scores[difficulty] = new Scores(difficulty);
				scores[difficulty].refresh();
			});
			return false;
		});
		
		if (score > 0) {
			//confirm resume
			paused = true;
			refreshHTML();
			resume(true);
		} else {
			$('#menu').show();
		}
		
		initialised = true;
	}
	
	//show menu
	function showMenu() {
		audio.playMusic(TITLE_TRACK);
		$('#menu').fadeIn(function() {
			$('#menu').attr('style', 'display:block'); //show menu
		});
	}
	
	//show instructions
	function showInstructions(callback) {
		var modal = Modal.custom(
			'<ul>' +
			'<li>Click on groups of adjacent blocks to remove them</li>' +
			'<li>Click on spinning rainbow blocks to scramble the surrounding blocks</li>' +
			'<li>Complete levels by removing all adjacent or spinning rainbow blocks</li>' +
			'<li>Game ends when you do not have enough points to advance</li>' +
			'</ul>'
		);
		modal.addClass('wide');
		modal.addButton('OK', function() {
			if (typeof callback == 'function') {
				callback();
			}
			modal.close();
		});
	}
	
	//show settings
	var settingsVisible = false;
	function showSettings(callback) {
		if (settingsVisible) {
			return;
		}
		settingsVisible = true;
		var modal = Modal.custom(
			'<h1>Settings</h1>' +
			'<form action="http://settings.rainbowblocks/update">' +
				'<div>' +
					'<label for="theme-select">Color Scheme</label>' +
					'<select id="theme-select" name="theme">' +
						'<option value="0">Pastels</option>' +
						'<option value="1">High Contrast</option>' +
					'</select>' +
				'</div>' +
				'<div>' +
					'<label for="pause-select">Pause Button</label>' +
					'<select id="pause-select" name="pauseButton">' +
						'<option value="0">Default</option>' +
						'<option value="1">Top Left</option>' +
						'<option value="2">Top Right</option>' +
						'<option value="3">Bottom Right</option>' +
						'<option value="4">Bottom Left</option>' +
					'</select>' +
				'</div>' +
				((CONSTANTS.GAME_CENTER)? '<div>' +
					'<label for="enable-game-center">Enable Game Center</label>' +
					'<input name="gameCenter" id="enable-game-center" type="checkbox">' +
				'</div>': '') + 
				((CONSTANTS.MOBILE_DEVICE)? '<div>' +
					'<label for="shake-to-undo">Shake To Undo</label>' +
					'<input name="shakeToUndo" id="shake-to-undo" type="checkbox">' +
				'</div>': '') +
				((CONSTANTS.DESKTOP_DEVICE)? '<div>' +
					'<label for="full-screen">Full Screen</label>' +
					'<input name="fullScreen" id="full-screen" type="checkbox">' +
				'</div>': '') +
				((CONSTANTS.DESKTOP_DEVICE)? '<div>' +
					'<label for="large-size">Large Scale</label>' +
					'<input name="useLargeView" id="large-size" type="checkbox">' +
				'</div>': '') +
				((CONSTANTS.NATIVE_APP)? '<div>' +
					'<label for="sound-enabled">Sound Effects</label>' +
					'<input name="soundEnabled" id="sound-enabled" type="checkbox">' +
				'</div>': '') +
				((CONSTANTS.NATIVE_APP)? '<div>' +
					'<label for="music-enabled">Music</label>' +
					'<input name="musicEnabled" id="music-enabled" type="checkbox">' +
				'</div>': '') +
			'</form>'
		);
		modal.addClass('wide');
		$('#theme-select').val(CONSTANTS.THEME);
		$('#pause-select').val(CONSTANTS.PAUSE_CORNER);
		$('#enable-game-center').attr('checked', (CONSTANTS.GAME_CENTER_ALIAS)? 'checked': '');
		$('#shake-to-undo').attr('checked', (CONSTANTS.SHAKE_TO_UNDO)? 'checked': '');
		$('#large-size').attr('checked', (CONSTANTS.WIDESCREEN)? 'checked': '');
		$('#full-screen').attr('checked', (CONSTANTS.FULLSCREEN)? 'checked': '');
		$('#sound-enabled').attr('checked', (CONSTANTS.SOUND_ENABLED)? 'checked': '');
		$('#music-enabled').attr('checked', (CONSTANTS.MUSIC_ENABLED)? 'checked': '');
		var submitted = false;
		modal.addButton('OK', function() {
			if (!submitted) {
				submitted = true;
				settingsVisible = false;
				setPauseCorner($('#pause-select').val());
				setShakeToUndo($('#shake-to-undo').attr('checked'));
				setTheme($('#theme-select').val());
				Blocks.setFullScreen($('#full-screen').attr('checked'));
				Blocks.setLarge($('#large-size').attr('checked'));
				Blocks.setSoundEnabled($('#sound-enabled').attr('checked'));
				Blocks.setMusicEnabled($('#music-enabled').attr('checked'));
				setTimeout(function() {
					if (CONSTANTS.NATIVE_APP) {
						modal.find('form').submit();
					}
					if (typeof callback == 'function') {
						callback();
					}
					modal.close();
				}, 150);
			} else {
				modal.close();
			}
		});
		modal.addButton('Cancel', function() {
			settingsVisible = false;
			if (typeof callback == 'function') {
				callback();
			}
			modal.close();
		});
		modal.find('.button').addClass('half');
	}
	
	//set theme
	function setTheme(theme) {
		$('body').removeClass('theme' + CONSTANTS.THEME).addClass('theme' + theme);
		$('#theme-select').val(theme);
		CONSTANTS.THEME = theme;
	}
	
	//set shake to undo
	function setShakeToUndo(shakeToUndo) {
		CONSTANTS.SHAKE_TO_UNDO = shakeToUndo;
		$('#shake-to-undo').attr('checked', shakeToUndo? 'checked': '');
	}
	
	//game center
	function setGameCenterAlias(alias) {
		CONSTANTS.GAME_CENTER_ALIAS = alias;
		if (alias) {
			$('#enable-game-center').attr('checked', 'checked');
			$('#scores').addClass('show-game-center');
		} else {
			$('#enable-game-center').removeAttr('checked');
			$('#scores').removeClass('show-game-center');
		}
	}
	
	//**************
	//touch events
	//**************
	
	function bindTouchEvent(element, event, callback) {
		element.bind(event, function(e) {
			if (e.touches.length == 1) {
				e.pageX = e.touches[0].pageX;
				e.pageY = e.touches[0].pageY;
			}
			callback.call(this, e);
		});
	}
	
	if(navigator.userAgent.match(/iPhone|iPod|iPad|Android/i)) {
		jQuery.event.props.push('touches');
		jQuery.fn.mousedown = function(callback) {
			bindTouchEvent(this, 'touchstart', callback);
		}
		jQuery.fn.mouseup = function(callback) {
			bindTouchEvent(this, 'touchend', callback);
		}
	}
	
	//**************
	//public methods
	//**************
	
	//first launch
	this.init = init;
	
	//initialise with saved state
	this.initWithGameState = function(data) {
		
		stage = new Stage($('#stage'), blockClicked);
		scores = {};
		scores[EASY] = new Scores(EASY);
		scores[NORMAL] = new Scores(NORMAL);
		scores[HARD] = new Scores(HARD);
		try {
			if (data.version <= VERSION) {
				if (data.difficulty) {
					difficulty = data.difficulty;
				}
				setDifficulty(difficulty);
				if (stage.load(data.blocks)) {
					score = data.score;
					scoreAtLevelStart = score - 1; //we don't record this
					level = data.level;
					//undo previous skipping
					while (level > 1 && score < levelCompletionTarget(level - 1)) {
						level--;
					}
					targetScore = levelCompletionTarget(level);
					undosRemaining = (data.undosRemaining === null || typeof(data.undosRemaining) == 'undefined')? UNDO_LIMIT: data.undosRemaining;
				}
				if (data.name) {
					name = data.name;
				}
				if (data.scores) {
					//legacy scores
					scores[NORMAL].load(data.scores);
				}
				if (data.scoresEasy) {
					scores[EASY].load(data.scoresEasy);
				}
				if (data.scoresNormal) {
					scores[NORMAL].load(data.scoresNormal);
				}
				if (data.scoresHard) {
					scores[HARD].load(data.scoresHard);
				}
			}
		} catch (e) {
			score = 0;
			stage = null;
		}
		init();
	}
	
	//save
	this.saveGameState = function() {
		return JSON.stringify({
			version:VERSION,
			blocks:stage.save(),
			difficulty:difficulty,
			level:level,
			score:score,
			undosRemaining:undosRemaining,
			scoresEasy:scores[EASY].save(),
			scoresNormal:scores[NORMAL].save(),
			scoresHard:scores[HARD].save(),
			name:name
		});
	}
	
	//pause / resume
	this.pause = pause;
	this.resume = resume;
	
	//refresh
	this.refresh = function() {
		stage.refresh();
		Modal.refresh();
	}
	
	//undo
	this.undo = undo;
	
	//reset scores
	this.resetScores = resetScores;
	
	//set pause corner
	this.setPauseCorner = setPauseCorner;
	
	//set theme
	this.setTheme = setTheme;
		
	//set shake to undo
	this.setShakeToUndo = setShakeToUndo;
	
	//large scale
	this.setLarge = function(){};
		
	//fullscreen
	this.setFullScreen = function(){};
	
	//sound
	this.setSoundEnabled = function(enabled) {
		this.CONSTANTS.SOUND_ENABLED = enabled;
		$('#sound-enabled').attr('checked', enabled? 'checked': '');
	};
		
	//music
	this.setMusicEnabled = function(enabled) {
		this.CONSTANTS.MUSIC_ENABLED = enabled;
		$('#music-enabled').attr('checked', enabled? 'checked': '');
		if (enabled) {
			if (gameRunning()) {
				audio.switchTrack();
			} else {
				audio.playMusic(TITLE_TRACK);
			}
		} else {
			audio.stopMusic();
		}
	};
	
	//game center prompt
	this.requestEnableGameCenter = requestEnableGameCenter;
	
	//enable game center
	this.setGameCenterAlias = setGameCenterAlias;
		
	//submit score error
	this.submitScoreError = function() {
		Modal.alert('Game Center Error\n\nUnable to submit your score to the global leaderboards. Will try again later.');
	}
	
	//game center login error
	this.gameCenterLoginError = function() {
		Modal.alert('Game Center Error\n\nUnable to log in to Game Center. Your scores will not be submitted to the global leaderboard.');
	}
	
	//game center cancelled
	this.gameCenterCancelled = gameCenterCancelled;
	
	//iVersion
	this.showNewVersion = function(version, details) {
		Modal.dialog('New Version Available (' + version + ')\n\n' + details, {
			'Download': function() {
				this.close();
				openURL('http://iVersion.rainbowblocks/viewedRemote');
			},
			'Remind Me Later': function() {
				this.close();
				openURL('http://iVersion.rainbowblocks/remind');
			},
			'Ignore': function() {
				this.close();
				openURL('http://iVersion.rainbowblocks/ignore?version=' + version);
			}
		}).addClass('wide');
	}
	this.showCurrentVersion = function(version, details) {
		Modal.alert('New In This Version (' + version + ')\n\n' + details, function() {
			openURL('http://iVersion.rainbowblocks/viewedLocal');
		}).addClass('wide');
	}
	
	//iNotify
	this.showNotification = function(key, title, message, actionURL, actionButtonLabel) {
		var modal = Modal.dialog(title + '\n\n' + message)
		if (actionURL) {
			modal.addButton(actionButtonLabel, function() {
				this.close();
				openURL('http://iNotify.rainbowblocks/viewed?key=' + key);
				setTimeout(function() {
					openURL(actionURL, true);
				}, 50);
			});
			modal.addButton('Remind Me Later', function() {
				this.close();
				openURL('http://iNotify.rainbowblocks/remind?key=' + key);
			});
			modal.addButton('Ignore', function() {
				this.close();
				openURL('http://iNotify.rainbowblocks/ignore?key=' + key);
			});
		} else {
			modal.addButton('OK', function() {
				this.close();
				openURL('http://iNotify.rainbowblocks/viewed?key=' + key);
			});
		}
		modal.addClass('wide');
	}
	
	//iRate
	this.showRatingPrompt = function() {
        Modal.custom("<p>If you enjoy playing Rainbow Blocks, would you mind taking a moment to rate it?</p>" +
					 "<p>It won't take more than a minute. Thanks for your support!</p>", {
			'Rate It Now': function() {
				this.close();
				openURL('http://iRate.rainbowblocks/rated');
			},
			'Remind Me Later': function() {
				this.close();
				openURL('http://iRate.rainbowblocks/remind');
			},
			'No, Thanks': function() {
				this.close();
				openURL('http://iRate.rainbowblocks/decline');
			}
		}).addClass('wide');
	}
	
	//show settings
	this.showSettings = showSettings;
	
	//configuration
	this.CONSTANTS = CONSTANTS;
}