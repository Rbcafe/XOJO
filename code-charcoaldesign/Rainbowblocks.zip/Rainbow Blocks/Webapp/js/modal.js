var Modal = new function() {
	
	var showTime;
	var stack = [];
	
	$('body').live('keydown', function(event) {
		$('#modal .button').trigger(event);
	});
	
	function messageToHtml(message) {
		var lines = message.replace(/\r\n?|\n/g, '<br>').replace(/<br>(<br>+)/g, '\n').split(/\n/);
		var html = '';
		var title = true;
		for (i = 0; i < lines.length; i++) {
			var line = lines[i].replace(/(^\s+)|(\s+$)/, '');
			if (line != '') {
				if (title) {
					html += '<h1>' + line + '</h1>';
					title = false;
				} else {
					html += '<p>' + line + '</p>';
				}
			}
		}
		return html;
	}
	
	//**************
	//public constants
	//**************
	
	this.DEFAULT = 13;
	this.CANCEL = 27;
	
	//**************
	//public methods
	//**************

	//generic modal
	this.custom = function(html, buttons, keyBindings) {
		
		//set show time
		showTime = new Date();
		
		//key bindings
		var keyBindings = $.extend({
			'OK': Modal.DEFAULT,
			'Continue': Modal.DEFAULT,
			'Cancel': Modal.CANCEL
		}, keyBindings || {});
		
		//remove existing modal
		$('#modal').detach();
		
		//create modal
		if (typeof(html) == 'undefined') html = '';
		var modal = $.extend({
			open: function() {
				//hide modal initially
				veil.append(modal);
				$('body').append(veil);
				modal.css({
					top: veil.height() * 0.5,
					left: 0,
					opacity: 0
				});
				//show modal
				setTimeout(function() {
					veil.fadeIn();
					modal.animate({
						top: (veil.height() - modal.height())/2,
						left: 0,
						opacity: 1
					});
				}, 0);
			},
			close: function(callback) {
				var index = stack.indexOf(modal);
				if (index == stack.length - 1) {
					modal.addClass('closing');
					stack.pop();
					if (stack.length) {
						if (typeof(callback) == 'function') {
							callback.call(modal[0]);
						}
						modal.remove();
						stack[stack.length - 1].open();
					} else {
						setTimeout(function() {
							veil.fadeOut();
							modal.animate({
								top: veil.height() * 0.5,
								left: 0
							}, function() {
								if (typeof(callback) == 'function') {
									callback.call(this);
								}
								$(this).remove();
							});
						}, 0);
					}
				} else {
					stack.splice(index);
				}
			},
			addButton: function(name, callback, disabled) {
				if (!!disabled) {
					modal.find('>div').append($('<div class="button disabled">' + name + '</div>'));
				} else {
					modal.find('>div').append($('<div class="button">' + name + '</div>').click(function(e) {
						if ((new Date()) - showTime > 500) {
							callback.call(modal);
						}
						return false;
					}).keydown(function(event) {
						if (event.which == keyBindings[name]) {
							$(this).click();
							return false;
						}
					}));
				}
			},
			bindKey: function(buttonName, keycode) {
				keyBindings[buttonName] = keycode;
			},
			bindKeys: function(bindings) {
				keyBindings = $.extend(keyBindings, bindings);
			},
		}, $('<div id="modal"><div>' + html + '</div></div>'));
		
		//add buttons
		if (typeof(buttons) == 'object') {
			for (name in buttons) {
				modal.addButton(name, buttons[name]);
			}
		}
		
		//create veil
		var veil = $('#veil');
		if (veil.length == 0) {
			veil = $('<div id="veil"></div>');
			veil.hide();
		}
		
		//show modal
		stack.push(modal);
		modal.open();
		
		//return modal object
		return modal;
	}
	
	//alert dialog
	this.dialog = function(message, buttons, keyBindings) {
		return this.custom(messageToHtml(message), buttons, keyBindings);
	}
	
	//alert modal
	this.alert = function(message, onClose) {
		return this.dialog(message, {
			'OK': function() {
				this.close(onClose);
			}
		});
	}
	
	//query modal
	this.confirm = function(message, onOK, onCancel) {
		var modal = this.dialog(message, {
			'OK': function() {
				this.close(onOK);
			},
			'Cancel': function() {
				this.close(onCancel);
			}
		});
		modal.find('.button').addClass('half');
		return modal;
	}
	
	//prompt modal
	this.prompt = function(message, value, onOK, onCancel) {
		var options = {};
		var modal = this.custom('<form>' + messageToHtml(message) + '</form>');
		if (typeof(value) == 'function') {
			onCancel = onOK;
			onOK = value;
		} else if (typeof(value) == 'object') {
			options = value;
		} else if (typeof(value) != 'undefined') {
			options.value = value;
		}
		var field = $('<input type="text">');
		for (attr in options) {
			field.attr(attr, options[attr]);
		}
		var form = modal.find('form').append($('<div class="field"></div>').append(field));
		modal.addButton('OK', function() {
			form.submit();
		});
		if (typeof(onOK) == 'function') {
			form.submit(function() {
				modal.close(function() {
					onOK(field.val());
				});
				return false;
			});
		} else {
			form.submit(function() {
				return false;
			});
		}
		if (typeof(onCancel) == 'function') {
			modal.addButton('Cancel', function() {
				this.close(onCancel);
			});
		} else if (typeof(onOK) == 'function') {
			modal.addButton('Cancel', function() {
				this.close(function() {
					onOK(null);
				});
			});
		} else {
			modal.addButton('Cancel', modal.close);
		}
		modal.find('.button').addClass('half');
		setTimeout(function() {
			field.find('input').focus();
		}, 1000);
		return modal;
	}
	
	//refresh current modal position
	this.refresh = function() {
		if (!$('#modal').hasClass('closing')) {
			$('#modal').css({
				top: ($('#veil').height() - $('#modal').height())/2,
				left: 0,
				opacity: 1
			});
		}
	}
}