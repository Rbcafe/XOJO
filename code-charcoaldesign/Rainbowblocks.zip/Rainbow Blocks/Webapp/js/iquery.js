/* an extension to jQuery that uses css3 transforms and animation, which are hardware accelerated on the iPhone */

(function() {
	
	function queueFn(element, fn, time) {
		var queue = jQuery.data(element, 'iqueue');
		if (!queue) {
			queue = [];
			jQuery.data(element, 'iqueue', queue);
		}
		queue.push(function() {
			fn();
			setTimeout(function() {
				queue.shift();
				if (queue.length > 0) {
					queue[0]();
				}
			}, time);
		});
		if (queue.length == 1) {
			queue[0]();
		}
	}
	function animateStyle(element, name, value, time, callback, async) {	
		if (typeof async !== 'undefined' && async) {
			setTimeout(function() {
				animateStyle(element, name, value, time, callback);
			}, 0);
			return;
		}
		if (typeof callback === 'function') {
			var timeoutNeeded = true;
			var timeout = setTimeout(function() {
				if (timeoutNeeded) {
					//element.style.cssText += name + ':' + value;
					callback.call(element);
					callback = function() {};
					timeoutNeeded = false;
				}
			}, time + 100);
			element.addEventListener('webkitTransitionEnd', function() {
				clearTimeout(timeout);
				element.removeEventListener('webkitTransitionEnd', arguments.callee);
				if (timeoutNeeded) {
					callback.call(element);
					callback = function() {};
					timeoutNeeded = false;
				}
			}, false);
		}
		element.style.cssText += ';-webkit-transition:' + time + 'ms ease-in-out;' + name + ':' + value;
	}

	jQuery.fn.jCss = jQuery.fn.css;
	jQuery.fn.iCss = function(name) {
		if (typeof name === 'object') {
			for (i in name) {
				if (i !== 'top' && i !== 'left') {
					this.jCss(i, name[i]);
				}
			}
			if (name.top !== undefined || name.left !== undefined) {
				var cssString = '';	
				if (name.top !== undefined && name.left !== undefined) {
					name.left = ('' + name.left).replace(/px$/, '');
					name.top = ('' + name.top).replace(/px$/, '');
					cssString = ';-webkit-transform:translate3d(' + name.left + 'px,' + name.top + 'px,0);';
				}
				else if (name.top !== undefined) {
					name.top = ('' + name.top).replace(/px$/, '');
					cssString = ';-webkit-transform:translateY(' + name.top + 'px);';
				}
				else if (name.left !== undefined) {
					name.left = ('' + name.left).replace(/px$/, '');
					cssString = ';-webkit-transform:translateX(' + name.left + 'px);';
				}
				this[0].style.cssText += cssString;
			}
			queueFn(this[0], function() {}, 0);
			return this;
		}
		return this.jCss.apply(this, arguments);
	}
	jQuery.fn.jAnimate = jQuery.fn.animate;
	jQuery.fn.iAnimate = function(name, time, callback) {
		if (typeof time === 'function' || typeof time === 'undefined') {
			callback = time;
			time = 400;
		}
		var count = 0;
		var styles = {};
		if (name.top !== undefined || name.left !== undefined) {
			count ++;
			if (name.top !== undefined && name.left !== undefined) {
				name.left = ('' + name.left).replace(/px$/, '');
				name.top = ('' + name.top).replace(/px$/, '');
				styles['-webkit-transform'] = 'translate3d(' + name.left + 'px,' + name.top + 'px,0)';
			}
			else if (name.top !== undefined) {
				name.top = ('' + name.top).replace(/px$/, '');
				styles['-webkit-transform'] = 'translateY(' + name.top + 'px)';
			}
			else if (name.left !== undefined) {
				name.left = ('' + name.left).replace(/px$/, '');
				styles['-webkit-transform'] = 'translateX(' + name.left + 'px)';
			}
		}
		for (i in name) {
			if (i !== 'top' && i !== 'left') {
				count ++;
				styles[i] = name[i];
			}
		}
		var element = this[0];
		queueFn(element, function() {
			for (i in styles) {
				animateStyle(element, i, styles[i], time, callback, false);
				callback = undefined;
			}
		}, time);
		return this;
	}
	jQuery.fn.jFadeOut = jQuery.fn.fadeOut;
	jQuery.fn.iFadeOut = function(time, callback) {
		if (typeof time === 'function' || typeof time === 'undefined') {
			callback = time;
			time = 400;
		}
		var element = this[0];
		queueFn(element, function() {
			animateStyle(element, 'opacity', 0, time, function() {
				jQuery.data(element, 'olddisplay', jQuery.css(element, 'display'));
				element.style.display = 'none';
				if (typeof callback !== 'undefined') {
					callback.call(this);
				}
			});
		}, time);
		return this;
	}
	jQuery.fn.jFadeIn = jQuery.fn.fadeIn;
	jQuery.fn.iFadeIn = function(time, callback) {
		if (typeof time === 'function' || typeof time === 'undefined') {
			callback = time;
			time = 400;
		}
		var display = this.data('olddisplay');
		if (this.css('display') === 'none') {
			if (!display || display === 'none') {
				display = 'block';
			}
			this.iCss({
				display: display,
				opacity: 0
			});
		}
		var element = this[0];
		queueFn(element, function() {
			animateStyle(element, 'opacity', 1, time, callback);
		}, time);
		return this;
	}
	
	//disable transitions & transform3d
	if(!navigator.userAgent.match(/iPhone|iPod|iPad/i)) {
		jQuery.fn.iCss = jQuery.fn.jCss;
		jQuery.fn.iAnimate = jQuery.fn.jAnimate;
		jQuery.fn.iFadeOut = jQuery.fn.jFadeOut;
		jQuery.fn.iFadeIn = jQuery.fn.jFadeIn;
	}
		
	jQuery.iQuery = {
		enable: function(enabled) {
			jQuery.fn.css = (enabled)? jQuery.fn.iCss: jQuery.fn.jCss;
			jQuery.fn.animate = (enabled)? jQuery.fn.iAnimate: jQuery.fn.jAnimate;
			jQuery.fn.fadeOut = (enabled)? jQuery.fn.iFadeOut: jQuery.fn.jFadeOut;
			jQuery.fn.fadeIn = (enabled)? jQuery.fn.iFadeIn: jQuery.fn.jFadeIn;
		}
	}

	//enable by default
	jQuery.iQuery.enable(true);

}());