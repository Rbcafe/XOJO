Rainbow Blocks
--------------------

Rainbow Blocks is a puzzle game for the iPhone and Mac. It is written
using a mix of Objective-C and HTML/CSS/JavaScript.

The use of web-based technologies for the core game mechanics makes it
extremely portable, and we have open-sourced the project so that others
can study the approach and possibly create their own games and
applications using the same principles.

Everything apart from the game graphics and game-specific JavaScript
logic is free to be used in both commercial and non-commercial open and
closed source applications under the simplified BSD licence.

Inside this repository you will find fully functioning versions of the
game for Mac, iPhone, iPad and modern Web browsers. There is also an
partially completed Android port.

Please check the LICENSE.txt file for more details about how you may use
these files. If you have any questions, or wish to use the source in a
capacity outside the included licensing terms then please contact us via
the web form link below:

http://charcoaldesign.co.uk/contact

If you would like to buy the game, you can get it from iTunes here:

http://itunes.apple.com/app/rainbow-blocks/id355313284?mt=8