var Modal = new function() {

	function messageToHtml(message) {
		var lines = message.replace(/\r\n?|\n/g, '<br>').replace(/<br>(<br>+)/g, '\n').split(/\n/);
		var html = '';
		var title = true;
		for (i = 0; i < lines.length; i++) {
			var line = lines[i].replace(/(^\s+)|(\s+$)/, '');
			if (line != '') {
				if (title) {
					html += '<h1>' + line + '</h1>';
					title = false;
				} else {
					html += '<p>' + line + '</p>';
				}
			}
		}
		return html;
	}
	
	//**************
	//public methods
	//**************

	//generic modal
	this.custom = function(html, buttons) {
	
		//remove existing modal
		$('#modal').remove();
		
		//create modal
		if (typeof(html) == 'undefined') html = '';
		var modal = $.extend({
			close: function(callback) {
				veil.fadeOut();
				modal.animate({
					top: 100
				}, function() {
					if (typeof(callback) == 'function') {
						callback.call(this);
					}
					$(this).remove();
				});
			},
			addButton: function(name, callback) {
				modal.append($('<div class="button">' + name + '</div>').click(function(e) {
					callback.call(modal);
					return false;
				}));
			}
		}, $('<div id="modal">' + html + '</div>'));
		
		//add buttons
		if (typeof(buttons) == 'object') {
			for (name in buttons) {
				modal.addButton(name, buttons[name]);
			}
		}
		
		//create veil
		var veil = $('#veil');
		if (veil.length == 0) {
			veil = $('<div id="veil"></div>');
			veil.hide();
		} else {
			modal.css({
				opacity: 0.0
			});
		}
		
		//hide modal initially
		veil.append(modal);
		$('body').append(veil);
		modal.css({
			position: 'relative',
			top: 100
		});
		
		//show modal
		veil.fadeIn();
		modal.animate({
			top: 0,
			opacity: 1.0
		});
		
		//return modal object
		return modal;
	}
	
	//alert dialog
	this.dialog = function(message, buttons) {
		return this.custom(messageToHtml(message), buttons);
	}
	
	//alert modal
	this.alert = function(message, onClose) {
		return this.custom(messageToHtml(message), {
			'OK': function() {
				this.close(onClose);
			}
		});
	}
	
	//query modal
	this.confirm = function(message, onOK, onCancel) {
		var modal = this.custom(messageToHtml(message), {
			'OK': function() {
				this.close(onOK);
			},
			'Cancel': function() {
				this.close(onCancel);
			}
		});
		modal.find('.button').addClass('half');
		return modal;
	}
	
	//prompt modal
	this.prompt = function(message, value, onOK, onCancel) {
		var options = {};
		var modal = this.custom('<form>' + messageToHtml(message) + '</form>');
		if (typeof(value) == 'function') {
			onCancel = onOK;
			onOK = value;
		} else if (typeof(value) == 'object') {
			options = value;
		} else if (typeof(value) != 'undefined') {
			options.value = value;
		}
		var field = $('<input type="text">');
		for (attr in options) {
			field.attr(attr, options[attr]);
		}
		var form = modal.find('form').append($('<div class="field"></div>').append(field));
		modal.addButton('OK', function() {
			form.submit();
		});
		if (typeof(onOK) == 'function') {
			form.submit(function() {
				modal.close(function() {
					onOK(field.val());
				});
				return false;
			});
		} else {
			form.submit(function() {
				return false;
			});
		}
		if (typeof(onCancel) == 'function') {
			modal.addButton('Cancel', function() {
				this.close(onCancel);
			});
		} else if (typeof(onOK) == 'function') {
			modal.addButton('Cancel', function() {
				this.close(function() {
					onOK(null);
				});
			});
		} else {
			modal.addButton('Cancel', modal.close);
		}
		modal.find('.button').addClass('half');
		setTimeout(function() {
			field.find('input').focus();
		}, 1000);
		return modal;
	}
	
}