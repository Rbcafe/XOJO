var Blocks = new function() {

	//compatibility
	var VERSION = 1.1;
	
	//layout constants
	var STAGE_WIDTH = 14;
	var STAGE_HEIGHT = 9;
	var BLOCK_WIDTH = 34;
	var BLOCK_HEIGHT = 33;
	
	//game constants
	var POINTS_PER_BLOCK = 5;
	var STARTING_POINT_TARGET = 750;
	var STARTING_MULTIPLIER = 1;
	var MULTIPLIER_INCREMENT = 2;
	var BONUS_START_PERCENT = 86;
	var BONUS_START_AMOUNT = 25;
	var BONUS_MULTIPLIER_INCREMENT = 2;
	var HIGH_SCORE_COUNT = 10;
	var DEFAULT_NAME = 'Anonymous';
	var TOP_LEFT = 1;
	var TOP_RIGHT = 2;
	var BOTTOM_RIGHT = 3;
	var BOTTOM_LEFT = 4;
	
	//preferences
	var FADE_ANIMATIONS = true;
	var DEMO_MODE = false;
	var PAUSE_CORNER = BOTTOM_RIGHT;
	
	//itunes
	var ITUNES_LINK = 'http://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=355313284&mt=8';
	
	//block types
	var SPECIAL = 'special';
	var BLOCKS = [
		'block1',
		'block2',
		'block3',
		'block4',
		'block5'
	];
	
	//game state
	var level = 1;
	var score = 0;
	var name = DEFAULT_NAME;
	var targetScore = STARTING_POINT_TARGET;
	var multiplier = STARTING_MULTIPLIER;
	var blocks = [];
	var scores = {names:[],scores:[]};
	var lastHighScoreIndex = -1;
	
	//preload images from manifest
	var images = [];
	$.get('manifest.manifest', function(text) {
		$.each(text.split(/\s+/), function() {
			if (/\.(png|gif|jpeg|jpg)$/.test(this) && !/^#/.test(this)) {
				var image = new Image(1,1); 
				image.src = this;
				images.push(image);
			}
		});
	});

	//initialise blocks
	function resetBlocks() {
		//set basic blocks
		for (var y = 0; y < STAGE_HEIGHT; y++) {
			blocks[y] = [];
			for (var x = 0; x < STAGE_WIDTH; x++) {
				blocks[y][x] = BLOCKS[Math.floor(Math.random() * BLOCKS.length)];
			}
		}
		//add specials
		for (var i = Math.floor(Math.random() * 3) + 2; i > 0; i--) {
			var y = Math.floor(Math.random() * STAGE_HEIGHT);
			var x = Math.floor(Math.random() * STAGE_WIDTH);
			switch (PAUSE_CORNER) {
			case TOP_LEFT:
				if (x == 0 && y == 0) x++;
				break;
			case TOP_RIGHT:
				if (x == STAGE_WIDTH - 1 && y == 0) x--;
				break;
			case BOTTOM_RIGHT:
			if (x == STAGE_WIDTH - 1 && y == STAGE_HEIGHT - 1) x--;
				break;
			case BOTTOM_LEFT:
				if (x == 0 && y == STAGE_HEIGHT - 1) x++;
				break;
			}
			blocks[y][x] = SPECIAL;
		}
	}
	
	//initialise scores
	function resetScores() {
		scores = {names:[],scores:[]};
		for (var i = 0; i < HIGH_SCORE_COUNT; i++) {
			scores.names.push('');
			scores.scores.push(0);
		}
	}
	
	//build block html
	function buildBlock(x, y, id) {
		return '<div class="block ' + blocks[y][x] + '"' + ((typeof(id) == 'undefined')? '': ' id="' + id + '"')
			+ ' style="top:' + y*BLOCK_HEIGHT + 'px; left: ' + x*BLOCK_WIDTH + 'px"></div>'
	}
	
	//hide elements, with or without fade effect
	function fadeOut(elements, callback) {
		if (FADE_ANIMATIONS) {
			elements.fadeOut(callback);
		} else {
			elements.hide(0, callback);
		}
	}
	
	//show elements, with or without fade effect
	function fadeIn(elements, callback) {
		if (FADE_ANIMATIONS) {
			elements.fadeIn(callback);
		} else {
			elements.show(0, callback);
		}
	}
	
	//refresh level html
	function refreshHTML() {
		//update blocks
		var markup = '';
		for (var y = 0; y < STAGE_HEIGHT; y++) {
			for (var x = 0; x < STAGE_WIDTH; x++) {
				var id = getId(x, y);
				if (blocks[y][x]) {
					markup += buildBlock(x, y, id);
				}
			}
		}
		$('#stage').html(markup);
		//update hud
		$('#score span').text(score);
		$('#level span').text(level);
		$('#target span:eq(0)').text(targetScore);
	}
	
	//refresh scores html
	function refreshScoresHTML() {
		$('#scores ol').html('');
		for (var i = 0; i < scores.scores.length; i++) {
			var li = $('<li></li>');
			li.text(scores.names[i]);
			li.append('<span>' + scores.scores[i] + '</span>');
			$('#scores ol').append(li);
		}
	}
	
	//reset game
	function resetGame() {
		resetBlocks();
		level = 1;
		score = 0;
		targetScore = STARTING_POINT_TARGET;
		multiplier = STARTING_MULTIPLIER;
	}
	
	//increment level
	function nextLevel() {
		resetBlocks();
		level++;
		targetScore += STARTING_POINT_TARGET * multiplier;
		multiplier += MULTIPLIER_INCREMENT;
	}
	
	//coord hashing
	function getId(x, y) {
		return 'block_' + x + '_' + y;
	}
	
	//show/hide pause button
	function updatePause() {
		switch (PAUSE_CORNER) {
		case TOP_LEFT:
			if (blocks[0][0] == SPECIAL) {
				$('#pause').fadeOut();
			} else {
				$('#pause').fadeIn();
			};
			break;
		case TOP_RIGHT:
			if (blocks[0][STAGE_WIDTH - 1] == SPECIAL) {
				$('#pause').fadeOut();
			} else {
				$('#pause').fadeIn();
			};
			break;
		case BOTTOM_RIGHT:
			if (blocks[STAGE_HEIGHT - 1][STAGE_WIDTH - 1] == SPECIAL) {
				$('#pause').fadeOut();
			} else {
				$('#pause').fadeIn();
			};
			break;
		case BOTTOM_LEFT:
			if (blocks[STAGE_HEIGHT - 1][0] == SPECIAL) {
				$('#pause').fadeOut();
			} else {
				$('#pause').fadeIn();
			};
			break;
		}
	}
	
	//special function
	function randomiseBlocks(pivotx, pivoty) {
		//weights
		var weights = {};
		for (var i = 0 ; i < BLOCKS.length; i++) {
			weights[BLOCKS[i]] = 0;
		}
		//specials
		var specials = 0;
		//randomise blocks
		for (var y = Math.max(0, pivoty - 2); y < Math.min(STAGE_HEIGHT, pivoty + 3); y++) {
			for (var x = Math.max(0, pivotx - 2); x < Math.min(STAGE_WIDTH, pivotx + 3); x++) {
				if (blocks[y][x]) {
					if (blocks[y][x] == SPECIAL) specials ++;
					blocks[y][x] = BLOCKS[Math.floor(Math.random() * BLOCKS.length)];
					weights[blocks[y][x]]++;
				}
			}
		}
		//set pivot value to most common
		var highest = BLOCKS[0];
		var highestWeight = 0;
		for (i in weights) {
			if (weights[i] > highestWeight) {
				highest = i;
				highestWeight = weights[i];
			}
		}
		blocks[pivoty][pivotx] = highest;
		//restore specials
		for (var i = 1 ; i < specials; i++) {
			var x = pivotx, y = pivoty;
			while ((x == pivotx && y == pivoty) || !blocks[y][x]) {
				x = Math.min(STAGE_WIDTH - 1, Math.max(0, pivotx + Math.floor(Math.random() * 5) - 2));
				y = Math.min(STAGE_HEIGHT - 1, Math.max(0, pivoty + Math.floor(Math.random() * 5) - 2));
			}
			blocks[y][x] = SPECIAL;
		}
		//update pause button
		updatePause();
		//redraw pivot blocks
		for (var y = Math.max(0, pivoty - 2); y < Math.min(STAGE_HEIGHT, pivoty + 3); y++) {
			for (var x = Math.max(0, pivotx - 2); x < Math.min(STAGE_WIDTH, pivotx + 3); x++) {
				if (blocks[y][x]) {
					//fade in new block and remove old
					var newBlock = $(buildBlock(x, y));
					newBlock.hide().data('id', getId(x, y));
					$('#stage').append(newBlock);
					fadeIn(newBlock, function() {
						var id = $(this).data('id');
						$('#' + id).remove();
						$(this).attr('id', id); 
					});
				}
			}
		}
	}
	
	//click function
	var falling = 0;
	var sliding = 0;
	function blockClicked() {
	
		if (falling || sliding) return false;
	
		var id = this.id;
		var x = parseInt(id.split('_')[1]);
		var y = parseInt(id.split('_')[2]);
		var block = blocks[y][x];
		var selected = $(this).hasClass('selected');
		
		if (block == SPECIAL) {
			//handle special
			
			//hilight
			$('.selected').removeClass('selected');
			$(this).addClass('selected');
			
			//randomise surrounding blocks
			randomiseBlocks(x, y);
			
			//test for end condition
			checkIfLevelEnded();
			
		} else if (block) {
			//handle normal
	
			//find all affected blocks
			var checked = [];
			var affected = [];
			findNeighbours(x, y, block, checked, affected);
		
			if (affected.length > 1) {
				
				//get affected id list
				var ids = '#' + affected.join(',#');
				
				//hilight
				$('.selected').removeClass('selected');
				$(ids).addClass('selected');
				
				//update score
				var points = affected.length * affected.length * POINTS_PER_BLOCK;
				score += points;
				$('#score span').text(score);
				
				//display points
				var pointsDiv = $('<div class="points" style="left:' + x*BLOCK_WIDTH + 'px;top:' +
					y*BLOCK_HEIGHT + 'px">' + points + '</div>');
				$('#stage').append(pointsDiv);
				pointsDiv.animate({
					marginTop: -100,
					opacity: 0
				}, 1000, function() {
					$(this).remove();
				});
				
				//remove from stage
				for (i = 0; i < affected.length; i++) {
					var id = affected[i];
					var x = parseInt(id.split('_')[1]);
					var y = parseInt(id.split('_')[2]);
					blocks[y][x] = null;
				}
				fadeOut($(ids), function() {
					$(this).remove();
				});
		
				//shift down
				for (x = 0; x < STAGE_WIDTH; x++) {
					var shift = 0;
					for (y = STAGE_HEIGHT - 1; y >= 0; y--) {
						if (!blocks[y][x]) {
							shift++;
						} else if (shift > 0) {
							blocks[y + shift][x] = blocks[y][x];
							blocks[y][x] = null;
							falling++;
							$('#' + getId(x, y))
								.attr('id', getId(x, y + shift))
								.animate({top: (y + shift) * BLOCK_HEIGHT}, function() {falling--});
						}
					}
				}
				
				//wait for previous animation to complete
				(function shiftRight() {
					if (!falling) {;
					
						//shift right
						var shift = 0;
						for (x = STAGE_WIDTH - 1; x >= 0; x--) {
							var shiftNeeded = true;
							for (y = 0; y < STAGE_HEIGHT; y++) {
								if (blocks[y][x]) {
									shiftNeeded = false;
									break;
								}
							}
							if (shiftNeeded) {
								shift++;
							} else if (shift > 0) {
								for (y = 0; y < STAGE_HEIGHT; y++) {
									blocks[y][x + shift] = blocks[y][x];
									blocks[y][x] = null;
									$('#' + getId(x, y)).each(function() {
										sliding++;
										$(this)
											.attr('id', getId(x + shift, y))
											.animate({left: (x + shift) * BLOCK_WIDTH}, function() {sliding--});
									});
								}
							}
						}
						
						(function checkEnd() {
							if (!sliding) {;		
								//update pause button
								updatePause();								
								//test for end condition
								checkIfLevelEnded();
							} else {
								setTimeout(checkEnd, 100);
							}
						})(); 
						
					} else {
						 setTimeout(shiftRight, 100);
					}
				})();  
			}
		}
		
		//cancel event
		return false;
	}
	
	//calculate percentageComplete
	function percentComplete() {
		var total = STAGE_WIDTH * STAGE_HEIGHT;
		var complete = 0;
		for (var y = 0; y < STAGE_HEIGHT; y++) {
			for (var x = 0; x < STAGE_WIDTH; x++) {
				if (!blocks[y][x]) complete++;
			}
		}
		return Math.round(complete/total * 100);
	}
	
	//calculate
	function completionBonus(percentComplete) {
		var bonus = 0;
		var bonusMultiplier = 1;
		for (var i = BONUS_START_PERCENT; i <= percentComplete; i++) {
			bonus += BONUS_START_AMOUNT * bonusMultiplier;
			bonusMultiplier += BONUS_MULTIPLIER_INCREMENT;
		}
		return bonus;
	}
	
	//has high score
	function isHighScore(score) {
		return (score > scores.scores[HIGH_SCORE_COUNT - 1]);
	} 
	
	//add high score
	function addHighScore(name, score) {
		for (var i = 0; i < HIGH_SCORE_COUNT; i++) {
			if (score > scores.scores[i]) {
				//slide scores down
				for (var j = HIGH_SCORE_COUNT - 1; j > i; j--) {
					scores.scores[j] = scores.scores[j - 1];
					scores.names[j] = scores.names[j - 1]
				}
				//set score
				scores.scores[i] = score;
				scores.names[i] = name;
				//note index
				lastHighScoreIndex = i;
				return;
			} 
		}
	}
	
	//check if level complete
	function checkIfLevelEnded() {
		var levelComplete = true;
		for (var y = 0; y < STAGE_HEIGHT; y++) {
			for (var x = 0; x < STAGE_WIDTH; x++) {
				var block = blocks[y][x];
				if (block == SPECIAL) {
					levelComplete = false;
					break;
				} else if (block) {
					var checked = [];
					var affected = [];
					findNeighbours(x, y, block, checked, affected);
					if (affected.length > 1) {
						levelComplete = false;
						break;
					}
				}
			}
			if (!levelComplete) break;
		}
		if (levelComplete) {
			var completed = percentComplete();
			var bonus = completionBonus(completed);
			score += bonus;
			if (score >= targetScore) {
				nextLevel();
				Modal.alert(
					'Level ' + (level - 1) + ' Complete\n\n' + 
					'Score: ' + score + '\n' +
					'Completed: ' + completed + '%\n' +
					'Bonus: ' + bonus,
				refreshHTML);
			} else {
				if (DEMO_MODE) {
					var modal = Modal.dialog('Thanks For Playing\n\nIf you like the game, please buy the full version', {
						'Buy Now':  function() {
							window.top.location = ITUNES_LINK;
						},
						'10': function() {}
					});
					var playAgainButton = modal.find('.button:last');
					var countdown = setInterval(function() {
						var count = parseInt(playAgainButton.html());
						playAgainButton.html(--count);
						if (count < 0) {
							clearInterval(countdown);
							playAgainButton.html('Play Again');
							playAgainButton.click(function() {
								modal.close();
								fadeIn($('#menu'));
								return false;
							});
						}
					}, 1000);
					modal.append(playAgainButton);
				} else if (isHighScore(score)) {
					Modal.prompt('High Score\n\nPlease enter your name', {placeholder: name, maxlength: 30}, function(newName) {
						if (newName) {
							name = newName.replace(/<[^>]*>/g, '') || DEFAULT_NAME;
							addHighScore(name, score);
							refreshScoresHTML();
							$('#scores li').eq(lastHighScoreIndex).addClass('hilight');
						}
						resetGame();
						fadeIn($('#scores'), function() {
							$('#menu').show();
						});
					});
				} else {
					resetGame();
					var modal = Modal.dialog('Game Over\n\nBetter luck next time!', {
						'Play Again': function() {
							resetGame();
							refreshHTML();
							this.close();
						},
						'Quit': function() {
							this.close(function() {
								fadeIn($('#scores'), function() {
									$('#menu').show();
								});
							});
						}
					});
				}
			}
		}
	}
	
	//find neighbours
	function findNeighbours(x, y, block, checked, affected) {
		var id = getId(x, y);
		if (!checked[id]) {
			checked[id] = true;
			if (blocks[y][x] == block) {
				affected.push(id);
				if (x > 0) findNeighbours(x-1, y, block, checked, affected);
				if (x < STAGE_WIDTH - 1) findNeighbours(x+1, y, block, checked, affected);
				if (y > 0) findNeighbours(x, y-1, block, checked, affected);
				if (y < STAGE_HEIGHT - 1) findNeighbours(x, y+1, block, checked, affected);
			}
		}
	}
	
	//pause
	function pause() {
		if (!$('#menu').is(':visible')) {
			$('#stage').addClass('paused');
			var modal = Modal.dialog('Paused', {
				'Resume': function() {
					modal.close(function() {
						$('#stage').removeClass('paused');
					});
				},
				'Instructions': function() {
					showInstructions(function() {
						$('#stage').removeClass('paused');
					});
				},
				'Quit': function() {
					Modal.confirm('Really Quit?\n\nAre you sure you want to quit your game?', function() {
						fadeIn($('#menu'), function() {
							resetGame();
							$('#stage').removeClass('paused');
						});
					}, function() {
						$('#stage').removeClass('paused');
					});
				}
			});
		}
	}
	
	//initialise
	function init() {
	
		//reset blocks if gamestate not loaded
		if (blocks.length == 0) {
			resetBlocks();
			resetScores();
		}
	
		//render html
		refreshHTML();
		refreshScoresHTML();
		
		//position pause
		switch(PAUSE_CORNER) {
		case TOP_LEFT:
			$('#pause').addClass('top-left');
			break;
		case TOP_RIGHT:
			$('#pause').addClass('top-right');
			break;
		case BOTTOM_RIGHT:
			$('#pause').addClass('bottom-right');
			break;
		case BOTTOM_LEFT:
			$('#pause').addClass('bottom-left');
			break;
		}
		
		//initialise game events
		$('.block').live('touchstart', blockClicked);
		$('.block').live('mousedown', blockClicked);
		$('#pause').live('mousedown', pause);
		
		//prevent rubber banding
		$(document).bind('touchmove', function() {
			return false;
		});
		
		//default screen
		$('#default').click(function() {
			fadeOut($(this));
			return false;
		});
		
		//scores
		$('#scores').click(function() {
			resetGame();
			refreshHTML();
			fadeOut($(this), function() {
				$(this).find('li.hilight').removeClass('hilight');
			});
			return false;
		});
		
		//menu screen
		$('#new-game').click(function() {
			resetGame();
			refreshHTML();
			fadeOut($('#menu'));
			return false;
		});
		$('#instructions').click(function() {
			showInstructions();
			return false;
		});
		$('#high-scores').click(function() {
			fadeIn($('#scores'));
			return false;
		});
		$('#buy-now').each(function() {
			DEMO_MODE = true;
			$(this).click(function() {
				window.top.location = ITUNES_LINK;
				return false;
			});
		});
		
		if (score > 0) {
			//confirm resume
			Modal.confirm('Resume?\n\nWould you like to resume the previous game?', function() {
				checkIfLevelEnded();
			}, function() {
				$('#menu').show();
			});
		} else {
			$('#menu').show();
		}
	}
	
	//show instructions
	function showInstructions (callback) {
		var modal = Modal.custom(
			'<ul>' +
			'<li>Click on groups of adjacent blocks to remove them</li>' +
			'<li>Click on rainbow blocks to scramble surrounding blocks</li>' +
			'<li>Complete levels by removing all adjacent and rainbow blocks</li>' +
			'<li>Game ends when you do not have enough points to advance</li>' +
			'</ul>'
		);
		modal.addClass('wide');
		modal.addButton('OK', function() {
			modal.close(callback);
		});
	}
	
	//**************
	//public methods
	//**************
	
	//first launch
	this.init = init;
	
	//initialise with saved state
	this.initWithGameState = function(data) {
		if (data.version <= VERSION) {
			blocks = data.blocks;
			level = data.level;
			score = data.score;
			if (data.name) {
				name = data.name;
			}
			if (data.scores) {
				scores = data.scores;
			} else {
				resetScores();
			}
			for (var i = 1; i < level; i++) {
				targetScore += STARTING_POINT_TARGET * multiplier;
				multiplier += MULTIPLIER_INCREMENT;
			}
		}
		init();
	}
	
	//save
	this.saveGameState = function() {
		return JSON.stringify({
			version:VERSION,
			blocks:blocks,
			level:level,
			score:score,
			scores:scores,
			name:name
		});
	}
	
	//pause
	this.pause = pause;
}