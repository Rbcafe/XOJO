package com.charcoaldesign.RainbowBlocks;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebSettings;

public class RainbowBlocks extends Activity {
	WebView webView;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        webView=(WebView)findViewById(R.id.webkit);
        
        WebSettings webSettings = webView.getSettings();
        webSettings.setSavePassword(false);
        webSettings.setSaveFormData(false);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setSupportZoom(false);
        
        webView.loadUrl("file:///android_asset/index.html");
    }
    
    public void onSaveInstanceState() {
    	
    }
}