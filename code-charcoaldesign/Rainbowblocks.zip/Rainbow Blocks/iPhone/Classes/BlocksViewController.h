//
//  BlocksViewController.h
//  Blocks
//
//  Created by Nick Lockwood on 15/04/2009.
//  Copyright Charcoal Design 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "URLDispatcher.h"

#ifndef BLOCKS_LITE
#import <GameKit/GameKit.h>
#endif


#define kGameStateFilename @"gamestate.json"


#ifndef BLOCKS_LITE
@interface BlocksViewController : UIViewController<UIWebViewDelegate, URLDispatcherDelegate, GKLeaderboardViewControllerDelegate> {
#else
@interface BlocksViewController : UIViewController<UIWebViewDelegate, URLDispatcherDelegate> {
#endif
	
	NSMutableArray *unsentScores;
    URLDispatcher *urlDispatcher;
    NSMutableArray *pendingScripts;
    BOOL webViewLoaded;
}

@property (nonatomic, retain) UIWebView *webView;
@property (nonatomic, retain) UIImageView *imageView;
@property (nonatomic, retain) URLDispatcher *urlDispatcher;

- (void)applicationWillResignActive:(UIApplication *)application;
- (void)applicationDidBecomeActive:(UIApplication *)application;
- (void)applicationWillTerminate:(UIApplication *)application;
- (void)applicationWillEnterForeground:(UIApplication *)application;
- (void)applicationDidEnterBackground:(UIApplication *)application;

@end

