//
//  GKLeaderboardViewController+Landscape.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 05/10/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GameKit/GameKit.h>


@interface GKLeaderboardViewController(Landscape)

@end
