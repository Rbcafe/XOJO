//
//  BlocksAppDelegate.m
//  Blocks
//
//  Created by Nick Lockwood on 15/04/2009.
//  Copyright Charcoal Design 2009. All rights reserved.
//

#import "BlocksAppDelegate.h"
#import "BlocksViewController.h"
#import "iVersion.h"
#import "iNotify.h"
#import "iRate.h"
#import "SoundManager.h"


@implementation BlocksAppDelegate

@synthesize window, viewController;

+ (void)initialize {
	
	//initialise defaults
	NSString *path = [[NSBundle mainBundle] pathForResource:@"Defaults" ofType:@"plist"];
    NSDictionary *defaults = [NSDictionary dictionaryWithContentsOfFile:path];
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaults];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    //initialise audio
    [SoundManager sharedManager].allowsBackgroundMusic = ![[NSUserDefaults standardUserDefaults] boolForKey:@"enableMusic"];
	[[SoundManager sharedManager] prepareToPlay];
    
	//initialise iVersion
	[iVersion sharedInstance].groupNotesByVersion = NO;
	[iVersion sharedInstance].showOnFirstLaunch = YES;
	[iVersion sharedInstance].applicationName = @"Rainbow Blocks";
	
#ifdef BLOCKS_LITE
	[iVersion sharedInstance].appStoreID = 382354877;
	[iVersion sharedInstance].localVersionsPlistPath = @"ReleaseNotes-Lite.plist";
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks-lite.plist";
#else
	[iVersion sharedInstance].appStoreID = 355313284;
	[iVersion sharedInstance].localVersionsPlistPath = @"ReleaseNotes.plist";
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks.plist";
#endif
	
#ifdef BLOCKS_DEBUG
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks-debug.plist";
	[iVersion sharedInstance].localDebug = YES;
	[iVersion sharedInstance].remoteDebug = YES;
#else
	[iVersion sharedInstance].localDebug = NO;
	[iVersion sharedInstance].remoteDebug = NO;
#endif
	
	//initialise iNotify
	[iNotify sharedInstance].remindButtonLabel = [iVersion sharedInstance].remindButtonLabel;
	[iNotify sharedInstance].debug = [iVersion sharedInstance].localDebug;

#ifdef BLOCKS_LITE
	[iNotify sharedInstance].notificationsPlistURL = @"http://charcoaldesign.co.uk/iNotify/rainbowblocks-lite.plist";
#else
	[iNotify sharedInstance].notificationsPlistURL = @"http://charcoaldesign.co.uk/iNotify/rainbowblocks.plist";
#endif
	
	//initialise iRate
	[iRate sharedInstance].appStoreID = [iVersion sharedInstance].appStoreID;
	[iRate sharedInstance].applicationName = [iVersion sharedInstance].applicationName;
	[iRate sharedInstance].remindButtonLabel = [iVersion sharedInstance].remindButtonLabel;
    [iRate sharedInstance].remindPeriod = 10;
	[iRate sharedInstance].debug = [iVersion sharedInstance].localDebug;
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	
	//create main window
	window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	
	//add main view to window
	viewController = [[BlocksViewController alloc] init]; 
    [window addSubview:viewController.view];
	
	//add notification delegates
	[iVersion sharedInstance].delegate = viewController.urlDispatcher;
	[iNotify sharedInstance].delegate = viewController.urlDispatcher;
	[iRate sharedInstance].delegate = viewController.urlDispatcher;
	
	//show window
    [window makeKeyAndVisible];
}

- (void)applicationWillResignActive:(UIApplication *)application {
	
	[viewController applicationWillResignActive:application];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	
	[viewController applicationDidBecomeActive:application];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	
	[viewController applicationDidEnterBackground:application];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
	
	[viewController applicationWillEnterForeground:application];
}

- (void)applicationWillTerminate:(UIApplication *)application {
	
	[viewController applicationWillTerminate:application];
}

- (void)dealloc {
	
    [viewController release];
    [window release];
    [super dealloc];
}


@end
