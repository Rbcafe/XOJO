//
//  UIWindow+Shakable.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 04/10/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIWindow(Shakable)

@end
