//
//  BlocksViewController.m
//  Blocks
//
//  Created by Nick Lockwood on 15/04/2009.
//  Copyright Charcoal Design 2009. All rights reserved.
//

#import "BlocksViewController.h"
#import "NSURL+QueryParams.h"
#include <sys/sysctl.h>
#import "SoundManager.h"
#import "Playlist.h"


@implementation BlocksViewController

@synthesize webView;
@synthesize imageView;
@synthesize urlDispatcher;

- (BOOL)isIPad {
	return UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad;
}

- (BOOL)isOlderDevice {
	
	//get hardware version
	size_t size;
	sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
	sysctlbyname("hw.machine", machine, &size, NULL, 0);
	NSString *platform = [NSString stringWithCString:machine encoding: NSUTF8StringEncoding];
	free(machine);
	
	//1st or 2nd gen iPhone/iPod Touch
	return [[NSSet setWithObjects:@"iPhone1,1", @"iPhone1,2", @"iPod1,1", @"iPod1,2", nil] containsObject:platform];
}

- (BOOL)isGameCenterAvailable {
	
    //check for presence of GKLocalPlayer API.
    if (!NSClassFromString(@"GKLocalPlayer")) {
		return NO;
	}
	
    //the device must be running running iOS 4.1 or later.
    NSString *reqSysVer = @"4.1";
    NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
    if ([currSysVer compare:reqSysVer options:NSNumericSearch] == NSOrderedAscending) {
		return NO;
	}
	
	//game center is not supported on iPhone/iPod 1st and 2nd gen
	return ![self isOlderDevice];
}

- (id)init {

	if ((self = [super init])) {
		
		//initialise scores
		unsentScores = [[NSMutableArray alloc] init];
		
		//create url dispatcher
		urlDispatcher = [[URLDispatcher alloc] init];
		urlDispatcher.delegate = self;
        
        //scripts
        pendingScripts = [[NSMutableArray alloc] init];
        
        //initialise playlist
		NSMutableArray *tracks = [NSMutableArray array];
        int i;
        for (i = 1; i < 10; i++)
        {
            [tracks addObject:[NSString stringWithFormat:@"track%i", i]];
        }
        [Playlist sharedInstance].shuffle = YES;
        [[Playlist sharedInstance] setTracks:tracks];
	}
	return self;
}

- (void)loadView {
	
	[super loadView];

	//create web view
	webView = [[UIWebView alloc] initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.height, self.view.frame.size.width)];
	webView.delegate = self;
	[self.view addSubview:webView];
	
	//get holding image
	BOOL landscape = NO;
	UIImage *image = nil;
	NSString *imageFile = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"UILaunchImageFile"];
	
	//check for landscape version
	if ([self isIPad]) {
		NSString *extension = [imageFile pathExtension];
		NSString *fileName = [imageFile stringByDeletingPathExtension];
		if ((image = [UIImage imageNamed:[NSString stringWithFormat:@"%@-Landscape.%@", fileName, extension]])) {
			landscape = YES;
		}
	}
	if (!image) {
		image = [UIImage imageNamed:imageFile];	
	}
		
	//create holding image view
	imageView = [[UIImageView alloc] initWithImage:image];
	[self.view addSubview:imageView];
	
	//rotate image view if neccessary
	if (!landscape) {
		CGFloat offset = (image.size.height - image.size.width)/2;
		CGAffineTransform transform = CGAffineTransformMakeRotation(-M_PI_2);
		transform = CGAffineTransformTranslate(transform, offset, offset);
		[imageView setTransform:transform];
	}
}

- (void)viewDidLoad {	

	//get html filename
	NSString *htmlFile = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"HTML"];
	htmlFile = ([self isIPad])? [htmlFile stringByAppendingString:@"~ipad"] : htmlFile;
	
	//get request for index page
	NSString *path = [[NSBundle mainBundle] pathForResource:htmlFile ofType:@"html"];
	NSURL *url = [NSURL fileURLWithPath: path];
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView
	[webView loadRequest:requestObj];

#ifndef BLOCKS_LITE
	
	//handle gamecenter notifications
	if ([self isGameCenterAvailable]) {
		[[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(gameCenterAuthenticationChanged)
													 name:GKPlayerAuthenticationDidChangeNotificationName
												   object:nil];
	}
	
#endif
	
	//shake to undo
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(deviceShaken)
												 name:@"DeviceShaken"
											   object:nil];
	
	[super viewDidLoad];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (NSString *)gameStateFilePath {
	
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:kGameStateFilename];
}

- (void)saveGameState {

	NSString *data = [webView stringByEvaluatingJavaScriptFromString:@"Blocks.saveGameState()"];
	
	if (data && ![data isEqualToString:@""]) {
		NSString *filePath = [self gameStateFilePath];
		[data writeToFile:filePath
			   atomically:YES
				 encoding:NSUTF8StringEncoding
					error:NULL];
	}
}

- (void)pauseGame {
	
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.pause(false)"];
}

- (void)resumeGame:(BOOL)prompt {
	
	NSString *script = [NSString stringWithFormat:@"Blocks.resume(%i)", prompt];
	[webView stringByEvaluatingJavaScriptFromString:script];
}

- (void)deviceShaken {
	
	if ([[NSUserDefaults standardUserDefaults] boolForKey:@"shakeToUndo"]) {
		[webView stringByEvaluatingJavaScriptFromString:@"Blocks.undo()"];
	}
}


#pragma mark -
#pragma mark Game Center support

#ifndef BLOCKS_LITE

- (void)sendUnsentScores {

	for (NSDictionary *score in [[unsentScores copy] autorelease]) {
		if ([[score objectForKey:@"player"] isEqualToString:[GKLocalPlayer localPlayer].playerID]) {
			GKScore *scoreReporter = [[[GKScore alloc] initWithCategory:[score objectForKey:@"category"]] autorelease];
			scoreReporter.value = [[score objectForKey:@"score"] integerValue];
			[scoreReporter reportScoreWithCompletionHandler:^(NSError *error) {
				if (error == nil) {
					[unsentScores removeObject:score];
				}
			}];
		}
	}
}

- (void)enableGameCenter:(BOOL)prompt {
	
	if (prompt) {
		
		static NSString *script = @"Blocks.setGameCenterAlias(null); Blocks.requestEnableGameCenter()";
		[webView stringByEvaluatingJavaScriptFromString:script];
		
	} else {
		
		[[GKLocalPlayer localPlayer] authenticateWithCompletionHandler:^(NSError *error) {
			if (error) {
				NSString *script = @"Blocks.setGameCenterAlias(null)";
				[webView stringByEvaluatingJavaScriptFromString:script];
				if ([error code] == GKErrorCancelled) {
					[webView stringByEvaluatingJavaScriptFromString:@"Blocks.gameCenterCancelled()"];
				} else {
					[webView stringByEvaluatingJavaScriptFromString:@"Blocks.gameCenterLoginError()"];
					NSLog(@"Game Center connection error %@", error);
				}
			} else {
				NSString *script = [NSString stringWithFormat:@"Blocks.setGameCenterAlias(\"%@\")", [GKLocalPlayer localPlayer].alias];
				[webView stringByEvaluatingJavaScriptFromString:script];
				[self sendUnsentScores];
			}
		}];
	}
}

- (void)gameCenterAuthenticationChanged {

	if ([GKLocalPlayer localPlayer].authenticated && [[NSUserDefaults standardUserDefaults] boolForKey:@"gameCenter"]) {
		
		//notify web view
		NSString *script = [NSString stringWithFormat:@"Blocks.setGameCenterAlias(\"%@\")", [GKLocalPlayer localPlayer].alias];
        [webView stringByEvaluatingJavaScriptFromString:script];
		
		//attempt to send unsent scores
		[self sendUnsentScores];
	
	} else {
		
		//notify web view
		NSString *script = @"Blocks.setGameCenterAlias(null)";
        [webView stringByEvaluatingJavaScriptFromString:script];
	}
}

- (NSString *)leaderboardCategory:(NSString *)difficulty {
	
	return [NSString stringWithFormat:@"com.charcoaldesign.rainbowblocks.%@.%@", difficulty, ([self isIPad])? @"ipad": @"iphone"];
}

- (void)showGlobalScores:(NSString *)difficulty {
    
    NSString *category = [self leaderboardCategory:difficulty];
    NSLog(@"category: %@", category);
    GKLeaderboardViewController *leaderboardController = [[GKLeaderboardViewController alloc] init];
    if (leaderboardController != nil) {
        leaderboardController.leaderboardDelegate = self;
        leaderboardController.category = category;
        leaderboardController.timeScope = GKLeaderboardTimeScopeAllTime;
        [self presentModalViewController:leaderboardController animated:YES];
        [leaderboardController release];
    }
}

- (void)submitScore:(NSInteger)score level:(NSInteger)level difficulty:(NSString *)difficulty {
 
    NSString *category = [self leaderboardCategory:difficulty];
    GKScore *scoreReporter = [[[GKScore alloc] initWithCategory:category] autorelease];
    scoreReporter.value = score*100 + level;
    [scoreReporter reportScoreWithCompletionHandler:^(NSError *error) {
        if (error != nil) {
            [unsentScores addObject:[NSDictionary dictionaryWithObjectsAndKeys:
                                     [NSNumber numberWithInteger:scoreReporter.value], @"score",
                                     scoreReporter.playerID, @"player",
                                     scoreReporter.category, @"category",
                                     scoreReporter.date, @"date",
                                     nil]];
            [webView stringByEvaluatingJavaScriptFromString:@"Blocks.submitScoreError()"];
            NSLog(@"Submit score error: %@", error);
        }
    }];
}

- (void)leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController {
	
    [self dismissModalViewControllerAnimated:YES];
}

#endif

#pragma mark -
#pragma mark Settings

- (void)loadSettings {
	
	//load settings
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	[settings synchronize];
    
	//set pause corner - this can take effect mid-game
	NSInteger pauseCorner = [settings integerForKey:@"pauseButton"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setPauseCorner(%i)", pauseCorner]];
    
    //set sound enabled - this can take effect mid-game
    BOOL soundEnabled = [settings boolForKey:@"soundEnabled"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setSoundEnabled(%i)", soundEnabled]];
    
    //set music enabled - this can take effect mid-game
    BOOL musicEnabled = [settings boolForKey:@"musicEnabled"];
    [SoundManager sharedManager].allowsBackgroundMusic = !musicEnabled;
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setMusicEnabled(%i)", musicEnabled]];
    
	//clear scores - this only applies next time it launches
	if ([settings boolForKey:@"resetScores"]) {
		[webView stringByEvaluatingJavaScriptFromString:@"Blocks.resetScores()"];
		[settings setBool:NO forKey:@"resetScores"];
	}
	
	//theme - this can take effect mid-game
	NSInteger theme = [settings integerForKey:@"theme"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setTheme(%i)", theme]];

	//shake to undo
	BOOL shakeToUndo = [settings boolForKey:@"shakeToUndo"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setShakeToUndo(%i)", shakeToUndo]];
	
#ifndef BLOCKS_LITE
	
	//load unsent scores
	[unsentScores setArray:[settings arrayForKey:@"unsentScores"]];
	
	//game center prompt
	if ([self isGameCenterAvailable] && [settings boolForKey:@"gameCenter"]) {
		[self enableGameCenter:![settings boolForKey:@"gameCenterPrompted"]];
	} else {
		NSString *script = @"Blocks.setGameCenterAlias(null)";
        [webView stringByEvaluatingJavaScriptFromString:script]; 
	}
	
#endif
	
}

- (void)saveSettings {
	
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	[settings setObject:unsentScores forKey:@"unsentScores"];	
	[settings synchronize];
}


#pragma mark -
#pragma mark URLDispatcherDelegate

- (void)openExternalURL:(NSURL *)url {
    
    [[UIApplication sharedApplication] openURL:url];
}

- (void)updateSettings:(NSDictionary *)params {
	
    NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
    
    //theme
    NSUInteger theme = [[params objectForKey:@"theme"] integerValue];
    [settings setInteger:theme forKey:@"theme"];
    
    //pause corner
    NSInteger pauseCorner = [[params objectForKey:@"pauseButton"] integerValue];
    [settings setInteger:pauseCorner forKey:@"pauseButton"];
    
    //sound
    BOOL soundEnabled = !![params objectForKey:@"soundEnabled"];
    [settings setBool:soundEnabled forKey:@"soundEnabled"];
    
    //music
    BOOL musicEnabled = !![params objectForKey:@"musicEnabled"];
    [SoundManager sharedManager].allowsBackgroundMusic = !musicEnabled;
    [settings setBool:musicEnabled forKey:@"musicEnabled"];
    
    //shake to undo
    BOOL shakeToUndo = !![params objectForKey:@"shakeToUndo"];
    [settings setBool:shakeToUndo forKey:@"shakeToUndo"];
    
#ifndef BLOCKS_LITE		
    
    //game center
    BOOL gameCenter = !![params objectForKey:@"gameCenter"];
    [settings setBool:gameCenter forKey:@"gameCenter"];
    if ([self isGameCenterAvailable] && [settings boolForKey:@"gameCenter"]) {
        [self enableGameCenter:NO];
    } else {
        NSString *script = @"Blocks.setGameCenterAlias(null)";
        [webView stringByEvaluatingJavaScriptFromString:script]; 
    }
    
#endif

}

- (void)executeJavaScript:(NSString *)script {

	if (webViewLoaded) {
        [webView stringByEvaluatingJavaScriptFromString:script];
    } else {
        [pendingScripts addObject:script];
    }
}

#pragma mark -
#pragma mark UIWebViewDelegate methods

//web view loaded
- (void)webViewDidFinishLoad:(UIWebView *)theWebView {
	
	//fade out holding image
	imageView.alpha = 0.99;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDelay:[self isOlderDevice]? 3.0: 1.0];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	imageView.alpha = 0.0;
	[UIView commitAnimations];
	
#ifndef BLOCKS_DEBUG
	
	//debug mode
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.CONSTANTS.DEBUG_MODE=false"];
	
#endif
	
#ifndef BLOCKS_LITE
	
	//game center available
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.CONSTANTS.GAME_CENTER=%i", [self isGameCenterAvailable]]];
	
#endif
	
	//load saved state
	NSString *filePath = [self gameStateFilePath];
	if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
		NSString *data = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:NULL];
		[theWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.initWithGameState(%@)", data]];
		[data release];
	} else {
		[theWebView stringByEvaluatingJavaScriptFromString:@"Blocks.init()"];
	}
    
    //execute pending scripts
    webViewLoaded = YES;
    for (NSString *script in pendingScripts) {
        [webView stringByEvaluatingJavaScriptFromString:script];
    }
	
	//load settings
	[self loadSettings];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	
    return ![urlDispatcher dispatchURL:[request URL]];
}


#pragma mark -
#pragma mark Pause / Fast switch

- (void)applicationWillResignActive:(UIApplication *)notification {
	
	[self pauseGame];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	
	[self resumeGame:NO];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	
	//save state in case we're terminated later
	[self saveGameState];
	[self saveSettings];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {

	[self loadSettings];
	[self resumeGame:YES];
}

#pragma mark -
#pragma mark Cleanup

// Save data
- (void)applicationWillTerminate:(UIApplication *)application {
	
	[self saveGameState];
	[self saveSettings];
}

- (void)viewDidUnload {
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	 
	self.webView = nil;
	self.imageView = nil;
}

- (void)dealloc {
	
	[webView release];
	[imageView release];
	[urlDispatcher release];
	[unsentScores release];
    [pendingScripts release];
    [super dealloc];
}

@end
