//
//  UIWindow+Shakable.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 04/10/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "UIWindow+Shakable.h"


@implementation UIWindow(Shakable)

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
	
    if (event.type == UIEventTypeMotion && event.subtype == UIEventSubtypeMotionShake) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"DeviceShaken" object:self];
    }
}

@end
