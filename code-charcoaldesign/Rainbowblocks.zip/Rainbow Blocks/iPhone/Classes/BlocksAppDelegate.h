//
//  BlocksAppDelegate.h
//  Blocks
//
//  Created by Nick Lockwood on 15/04/2009.
//  Copyright Charcoal Design 2009. All rights reserved.
//

#import <UIKit/UIKit.h>


@class BlocksViewController;

@interface BlocksAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) BlocksViewController *viewController;

@end

