//
//  main.m
//  Blocks
//
//  Created by Nick Lockwood on 15/04/2009.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"BlocksAppDelegate");
    [pool release];
    return retVal;
}
