//
//  main.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/12/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "validatereceipt.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	
	NSString * pathToReceipt = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Contents/_MASReceipt/receipt"];
	
#if (VALIDATE_RECEIPT)

	if (!validateReceiptAtPath(pathToReceipt)) {
		exit(173);
	}
	
#else
	
	validateReceiptAtPath(pathToReceipt);
	
#endif
	
    [pool drain];
    return NSApplicationMain(argc,  (const char **) argv);
}