//
//  RainbowBlocksWindowController.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/12/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#import "URLDispatcher.h"


#define kGameStateFilename @"gamestate.json"


@interface BlocksWindowController : NSWindowController <URLDispatcherDelegate> {
	
	NSUndoManager *undoManager;
	WebView *webView;
    NSImageView *imageView;
    NSButton *windowButton;
    NSButton *closeButton;
    URLDispatcher *urlDispatcher;
	BOOL large;
	BOOL fullScreen;
    NSMutableArray *pendingScripts;
    BOOL webViewLoaded;
}

@property (nonatomic, retain) WebView *webView;
@property (nonatomic, retain) NSImageView *imageView;
@property (nonatomic, retain) IBOutlet NSButton *windowButton;
@property (nonatomic, retain) IBOutlet NSButton *closeButton;
@property (nonatomic, assign) BOOL large;
@property (nonatomic, assign) BOOL fullScreen;
@property (nonatomic, retain) URLDispatcher *urlDispatcher;

- (void)applicationWillTerminate:(NSApplication *)application;

- (IBAction)setFullSize:(id)sender;
- (IBAction)setHalfSize:(id)sender;
- (IBAction)showPreferences:(id)sender;
- (IBAction)pause:(id)sender;
- (IBAction)resume:(id)sender;
- (IBAction)toggleFullscreen:(id)sender;
- (IBAction)quit:(id)sender;

@end
