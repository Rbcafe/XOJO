//
//  RainbowBlocksWindowController.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/12/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "BlocksWindowController.h"
#import <QuartzCore/QuartzCore.h>
#import "Playlist.h"


@implementation BlocksWindowController

@synthesize webView;
@synthesize imageView;
@synthesize closeButton;
@synthesize windowButton;
@synthesize large;
@synthesize fullScreen;
@synthesize urlDispatcher;

- (void)awakeFromNib {
	
	//create undo manager
	undoManager = [[NSUndoManager alloc] init];
	[undoManager setLevelsOfUndo:1];
    
    //create url dispatcher
    urlDispatcher = [[URLDispatcher alloc] init];
    urlDispatcher.delegate = self;
    
    //initialise playlist
    NSMutableArray *tracks = [NSMutableArray array];
    int i;
    for (i = 1; i < 10; i++)
    {
        [tracks addObject:[NSString stringWithFormat:@"track%i", i]];
    }
    [Playlist sharedInstance].shuffle = YES;
    [[Playlist sharedInstance] setTracks:tracks];
	
	//disable window resize handle
	[[self window] setShowsResizeIndicator:NO];
	
	//center window
	[[self window] center];
    
	//create web view
	webView = [[WebView alloc] initWithFrame:[[[self window] contentView] bounds]];
	[webView setAutoresizingMask:NSViewMinYMargin | NSViewMaxYMargin | NSViewMinXMargin | NSViewMaxXMargin];
	[[[webView mainFrame] frameView] setAllowsScrolling:NO];
	[webView setUIDelegate:self];
	[webView setPolicyDelegate:self];
	[[[self window] contentView] addSubview:webView];

	//set default window size
	NSRect safeRect = [[NSScreen mainScreen] visibleFrame];
	NSRect windowRect = [[self window] frame];
	if ([[NSUserDefaults standardUserDefaults] objectForKey:@"useLargeView"]) {
		self.large = [[NSUserDefaults standardUserDefaults] boolForKey:@"useLargeView"];
	} else {
		self.large = (safeRect.size.width >= windowRect.size.width && safeRect.size.height >= windowRect.size.height);
	}
    
    //create image view
    imageView = [[NSImageView alloc] initWithFrame:[[[self window] contentView] bounds]];
    [imageView setWantsLayer:YES];
    imageView.image = [NSImage imageNamed:(large? @"default-large.jpg": @"default.jpg")];
    [imageView setAutoresizingMask:NSViewMinYMargin | NSViewMaxYMargin | NSViewMinXMargin | NSViewMaxXMargin];
	[[[self window] contentView] addSubview:imageView];
		
	//get html filename
	NSString *htmlFile = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"HTML"];
	
	//get request for index page
	NSString *path = [[NSBundle mainBundle] pathForResource:htmlFile ofType:@"html"];
	NSURL *url = [NSURL fileURLWithPath: path];
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView
	[[webView mainFrame] loadRequest:requestObj];
	
	//register for events
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(webViewDidFinishLoad:)
												 name:WebViewProgressFinishedNotification
											   object:webView];
}

- (NSString *)gameStateFilePath {
	
	NSString *identifier = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"];
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
	NSString *supportDirectory = [[paths objectAtIndex:0] stringByAppendingPathComponent:identifier];
	
	if (![[NSFileManager defaultManager] fileExistsAtPath:supportDirectory]) {
		[[NSFileManager defaultManager] createDirectoryAtPath:supportDirectory withIntermediateDirectories:YES attributes:nil error:NULL];
	}
	
	return [supportDirectory stringByAppendingPathComponent:kGameStateFilename];
}

- (void)saveGameState {
	
	NSString *data = [webView stringByEvaluatingJavaScriptFromString:@"Blocks.saveGameState()"];
	
	if (data && ![data isEqualToString:@""]) {
		NSString *filePath = [self gameStateFilePath];
		[data writeToFile:filePath
			   atomically:YES
				 encoding:NSUTF8StringEncoding
					error:NULL];
	}
}

- (void)pauseGame {
	
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.pause(false)"];
}

- (void)resumeGame:(BOOL)prompt {
	
	NSString *script = [NSString stringWithFormat:@"Blocks.resume(%i)", prompt];
	[webView stringByEvaluatingJavaScriptFromString:script];
}

- (NSRect)contentRect:(BOOL)_large
{
	return (_large)? NSMakeRect(0, 0, 960, 640): NSMakeRect(0, 0, 480, 330);
}

- (NSRect)windowWillUseStandardFrame:(NSWindow *)window defaultFrame:(NSRect)newFrame {
	
	//calculate current center
	NSRect currentRect = [window frame];
	NSPoint center = NSMakePoint(currentRect.origin.x + currentRect.size.width/2.0, currentRect.origin.y + currentRect.size.height/2.0);
	
	//calculate new rect
	NSRect newContentRect = (newFrame.size.width == 480)? NSMakeRect(0, 0, 960, 640): NSMakeRect(0, 0, 480, 330);
	NSRect newRect = [window frameRectForContentRect:newContentRect];
	newRect.origin = NSMakePoint(center.x - newRect.size.width/2.0, center.y - newRect.size.height/2.0);
	return newRect;
}

- (void)setLarge:(BOOL)_large animated:(BOOL)animated {
			
	BOOL prevLarge = large;
	large = _large;
    
	//calculate new window frame
	NSRect newRect = [self windowWillUseStandardFrame:[self window] defaultFrame:[self contentRect:!large]];
	
	if (![[[self window] contentView] isInFullScreenMode] && prevLarge) {
		
		//resize window first
		[[self window] setFrame:newRect display:animated animate:animated];
	}

	//set graphics size
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setLarge(%i)", large]];
	[webView setFrameSize:[self contentRect:large].size];

    //set holding image size
    imageView.image = [NSImage imageNamed:(large? @"default-large.jpg": @"default.jpg")];
    [imageView setFrameSize:[self contentRect:large].size];
    
	if ([[[self window] contentView] isInFullScreenMode]) {
	
		//center web view
		NSSize windowSize = [[[self window] contentView] frame].size;
		NSSize contentSize = [webView frame].size;
		NSPoint offset = NSMakePoint((windowSize.width - contentSize.width)/2, (windowSize.height - contentSize.height)/2);
		[webView setFrameOrigin:offset];
        [imageView setFrameOrigin:offset];
		
		//redraw background
		[[[self window] contentView] setNeedsDisplay:YES];
		
	} else if (!prevLarge) {
		
		//resize window after
		[[self window] setFrame:newRect display:animated animate:animated];
	}

	//save size
	[[NSUserDefaults standardUserDefaults] setBool:large forKey:@"useLargeView"];
}

- (void)setLarge:(BOOL)_large {
	
	[self setLarge:_large animated:NO];
}

- (IBAction)setFullSize:(id)sender {
	
	[self setLarge:YES animated:YES];
}

- (IBAction)setHalfSize:(id)sender {
	
	[self setLarge:NO animated:YES];
}

- (IBAction)showPreferences:(id)sender {

	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.showSettings()"];
}

- (IBAction)pause:(id)sender {

	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.pause(true)"];
}

- (IBAction)resume:(id)sender {
	
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.resume()"];
}

- (void)setFullScreen:(BOOL)_fullScreen {
	
	fullScreen = _fullScreen;
	NSView *contentView = [[self window] contentView];
    if (fullScreen) {
        
        if (![contentView isInFullScreenMode]) {
            [contentView enterFullScreenMode:[[contentView window] screen] withOptions:nil];
        }
        [webView removeFromSuperview];
        [contentView addSubview:webView];
		
	} else {
		
        if ([contentView isInFullScreenMode]) {
            [contentView exitFullScreenModeWithOptions:nil];
		}
        [self setLarge:large];
	}
	
    //update buttons
    closeButton.layer.opacity = 0.25;
    [closeButton setHidden:!fullScreen];
    windowButton.layer.opacity = 0.25;
    [windowButton setHidden:!fullScreen];
    
	//update web view
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setFullScreen(%i)", fullScreen]];
	
	//save state
	[[NSUserDefaults standardUserDefaults] setBool:fullScreen forKey:@"fullScreen"];
}

- (IBAction)toggleFullscreen:(id)sender {
	
    [self setFullScreen:![[[self window] contentView] isInFullScreenMode]];
}

- (BOOL)windowShouldZoom:(NSWindow *)window toFrame:(NSRect)newFrame {
	
	[self setLarge:(newFrame.size.width == 960) animated:YES];
	return NO;
}

- (IBAction)quit:(id)sender {
    
    [[NSApplication sharedApplication] terminate:nil]; 
}

- (NSUndoManager *)windowWillReturnUndoManager:(NSWindow *)window {

	return undoManager;
}

- (void)undo {
	
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.undo()"];
}

- (void)fadeHoldingImage {
 
    CATransition *transition = [CATransition animation];
    transition.duration = 1.5;
	transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	transition.type = kCATransitionFade;    
	[[imageView layer] addAnimation:transition forKey:nil];
    imageView.layer.opacity = 0.0;
    
    [self performSelector:@selector(setImageView:) withObject:nil afterDelay:transition.duration];
}

#pragma mark -
#pragma mark Settings

- (void)loadSettings {
	
	//load settings
	NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
	[settings synchronize];
	
	//set pause corner - this can take effect mid-game
	NSInteger pauseCorner = [settings integerForKey:@"pauseButton"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setPauseCorner(%i)", pauseCorner]];
    
    //set sound enabled - this can take effect mid-game
    BOOL soundEnabled = [settings boolForKey:@"soundEnabled"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setSoundEnabled(%i)", soundEnabled]];
    
    //set music enabled - this can take effect mid-game
    BOOL musicEnabled = [settings boolForKey:@"musicEnabled"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setMusicEnabled(%i)", musicEnabled]];
	
	//clear scores - this only applies next time it launches
	if ([settings boolForKey:@"resetScores"]) {
		[webView stringByEvaluatingJavaScriptFromString:@"Blocks.resetScores()"];
		[settings setBool:NO forKey:@"resetScores"];
	}
	
	//theme - this can take effect mid-game
	NSInteger theme = [settings integerForKey:@"theme"];
	[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.setTheme(%i)", theme]];
	
	//large
	self.large = [settings boolForKey:@"useLargeView"];
	
	//fullscreen
	self.fullScreen = [settings boolForKey:@"fullScreen"];
}


#pragma mark -
#pragma mark WebView notification methods

- (void)webViewDidFinishLoad:(NSNotificationCenter *)notification {

    //fade out holding image
	imageView.layer.opacity = 0.99;
	[self performSelector:@selector(fadeHoldingImage) withObject:nil afterDelay:1.5];
    
	//load settings
	[self loadSettings];
	
	//demo mode
#ifdef BLOCKS_LITE

	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.CONSTANTS.DEMO_MODE=true"];
	
#else
	
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.CONSTANTS.DEMO_MODE=false"];
	
#endif
	
#ifndef BLOCKS_DEBUG
	
	//debug mode
	[webView stringByEvaluatingJavaScriptFromString:@"Blocks.CONSTANTS.DEBUG_MODE=false"];
	
#endif
    
    //execute pending scripts
    webViewLoaded = YES;
    for (NSString *script in pendingScripts) {
        [webView stringByEvaluatingJavaScriptFromString:script];
    }
	
	//load saved state
	NSString *filePath = [self gameStateFilePath];
	if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
		NSString *data = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:NULL];
		[webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"Blocks.initWithGameState(%@)", data]];
		[data release];
	} else {
		[webView stringByEvaluatingJavaScriptFromString:@"Blocks.init()"];
	}
}

#pragma mark -
#pragma mark WebViewUIDelegate methods

- (NSArray *)webView:(WebView *)sender contextMenuItemsForElement:(NSDictionary *)element 
    defaultMenuItems:(NSArray *)defaultMenuItems {
    
	//disable right-click menu
    return nil;
}

#pragma mark -
#pragma mark WebPolicyDelegate methods

- (void)webView:(WebView *)sender decidePolicyForNavigationAction:(NSDictionary *)actionInformation
		request:(NSURLRequest *)request frame:(WebFrame *)frame decisionListener:(id<WebPolicyDecisionListener>)listener {

    if ([urlDispatcher dispatchURL:[request URL]]) {
        [listener ignore];
    } else {
        [listener use];
    }
}

#pragma mark -
#pragma mark URLDispatcherDelegate

- (void)openAppPageWhenAppStoreLaunched:(NSURL *)url {
    
	//check if app store is running
    ProcessSerialNumber psn = { kNoProcess, kNoProcess };
    while (GetNextProcess(&psn) == noErr)
	{
        CFDictionaryRef cfDict = ProcessInformationCopyDictionary(&psn,  kProcessDictionaryIncludeAllInformationMask);
		NSString *bundleID = [(NSDictionary *)cfDict objectForKey:(NSString *)kCFBundleIdentifierKey];
		if ([@"com.apple.appstore" isEqualToString:bundleID])
		{
			//open app page
			[[NSWorkspace sharedWorkspace] performSelector:@selector(openURL:) withObject:url afterDelay:2];
			CFRelease(cfDict);
			return;
		}
		CFRelease(cfDict);
    }
	
	//try again
	[self performSelector:@selector(openAppPageWhenAppStoreLaunched) withObject:nil afterDelay:0];
}

- (void)openExternalURL:(NSURL *)url {

    [[NSWorkspace sharedWorkspace] openURL:url];
    if ([[url scheme] isEqualToString:@"macappstore"]) {
        [self openAppPageWhenAppStoreLaunched:url];
    }
}

- (void)exitFullScreen {
    
    self.fullScreen = NO;
}

- (void)quit {
    
    [self quit:nil];
}

- (void)updateSettings:(NSDictionary *)params {
	
    NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
    
    //theme
    NSUInteger theme = [[params objectForKey:@"theme"] integerValue];
    [settings setInteger:theme forKey:@"theme"];
    
    //pause corner
    NSInteger pauseCorner = [[params objectForKey:@"pauseButton"] integerValue];
    [settings setInteger:pauseCorner forKey:@"pauseButton"];
    
    //sound
    BOOL soundEnabled = !![params objectForKey:@"soundEnabled"];
    [settings setBool:soundEnabled forKey:@"soundEnabled"];
    
    //music
    BOOL musicEnabled = !![params objectForKey:@"musicEnabled"];
    [settings setBool:musicEnabled forKey:@"musicEnabled"];
    
    //large size
    self.large = !![params objectForKey:@"useLargeView"];
    
    //fullscreen
    self.fullScreen = !![params objectForKey:@"fullScreen"];
    
    //save settings
    [settings synchronize];
}

- (void)updateUndo:(NSUInteger)undosRemaining {
	
    [undoManager setActionName:(undosRemaining > 0)? [NSString stringWithFormat:@"(%i Available)", undosRemaining]: @""];
    if (undosRemaining) {
        [undoManager registerUndoWithTarget:self selector:@selector(undo) object:nil];
    } else {
        [undoManager removeAllActions];
    }
}

- (void)executeJavaScript:(NSString *)script {
	
	if (webViewLoaded) {
        [webView stringByEvaluatingJavaScriptFromString:script];
    } else {
        [pendingScripts addObject:script];
    }
}


#pragma mark -
#pragma mark Cleanup

- (void)windowWillClose:(NSNotification *)notification {
	
	[[NSUserDefaults standardUserDefaults] synchronize];
	[self saveGameState];
}

- (void)applicationWillTerminate:(NSApplication *)application {
	
	[[NSUserDefaults standardUserDefaults] synchronize];
	[self saveGameState];
}

- (void)dealloc {
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];	
	[undoManager release];
    [closeButton release];
    [windowButton release];
    [webView release];
    [imageView release];
    [pendingScripts release];
	[super dealloc];
}

@end
