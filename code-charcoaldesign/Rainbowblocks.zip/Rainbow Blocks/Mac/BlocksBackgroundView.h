//
//  BlocksBackgroundView.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 20/02/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BlocksBackgroundView : NSView {

}

@end
