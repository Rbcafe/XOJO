//
//  HoverButton.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 23/03/2011.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "HoverButton.h"


@implementation HoverButton

- (void)updateTrackingAreas {
    
	[super updateTrackingAreas];
	
	if (area) {
		[self removeTrackingArea:area];
		[area release];
	}
	
	NSTrackingAreaOptions options = NSTrackingInVisibleRect | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow;
	area = [[NSTrackingArea alloc] initWithRect:NSZeroRect options:options owner:self userInfo:nil];
	[self addTrackingArea:area];
}

- (void)mouseEntered:(NSEvent *)event {
    
	self.layer.opacity = 1.0;
}

- (void)mouseExited:(NSEvent *)event {
    
	self.layer.opacity = 0.25;
}

@end
