//
//  RainbowBlocksAppDelegate.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/12/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "BlocksAppDelegate.h"
#import "BlocksWindowController.h"
#import "iVersion.h"
#import "iNotify.h"
#import "iRate.h"


@implementation BlocksAppDelegate

@synthesize window;
@synthesize windowController;

+ (void)initialize {
	
	//initialise defaults
	NSString *path = [[NSBundle mainBundle] pathForResource:@"Defaults" ofType:@"plist"];
    NSDictionary *defaults = [NSDictionary dictionaryWithContentsOfFile:path];
    [[NSUserDefaults standardUserDefaults] registerDefaults:defaults];
	
	//initialise iVersion
	[iVersion sharedInstance].groupNotesByVersion = NO;
	[iVersion sharedInstance].showOnFirstLaunch = YES;
	[iVersion sharedInstance].applicationName = @"Rainbow Blocks";
	
#ifdef BLOCKS_LITE
	[iVersion sharedInstance].appStoreID = 414057502;
	[iVersion sharedInstance].localVersionsPlistPath = @"ReleaseNotes-Lite.plist";
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks-mac-lite.plist";
#else
	[iVersion sharedInstance].appStoreID = 412363063;
	[iVersion sharedInstance].localVersionsPlistPath = @"ReleaseNotes.plist";
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks-mac.plist";
#endif
	
#if defined BLOCKS_DEBUG
	[iVersion sharedInstance].remoteVersionsPlistURL = @"http://charcoaldesign.co.uk/iVersion/rainbowblocks-mac-debug.plist";
	[iVersion sharedInstance].localDebug = YES;
	[iVersion sharedInstance].remoteDebug = YES;
#else
	[iVersion sharedInstance].localDebug = NO;
	[iVersion sharedInstance].remoteDebug = NO;
#endif
	
	//initialise iNotify
	[iNotify sharedInstance].remindButtonLabel = [iVersion sharedInstance].remindButtonLabel;
	
#ifdef BLOCKS_LITE
	[iNotify sharedInstance].notificationsPlistURL = @"http://charcoaldesign.co.uk/iNotify/rainbowblocks-mac-lite.plist";
#else
	[iNotify sharedInstance].notificationsPlistURL = @"http://charcoaldesign.co.uk/iNotify/rainbowblocks-mac.plist";
#endif
	
#if defined BLOCKS_DEBUG
	[iNotify sharedInstance].debug = YES;
#else
	[iNotify sharedInstance].debug = NO;
#endif
	
	//initialise iRate
	[iRate sharedInstance].appStoreID = [iVersion sharedInstance].appStoreID;
	[iRate sharedInstance].applicationName = [iVersion sharedInstance].applicationName;
	[iRate sharedInstance].remindButtonLabel = [iVersion sharedInstance].remindButtonLabel;
    [iRate sharedInstance].remindPeriod = 10;

#if defined BLOCKS_DEBUG
	[iRate sharedInstance].debug = YES;
#else
	[iRate sharedInstance].debug = NO;
#endif
	
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

	[iVersion sharedInstance].delegate = windowController.urlDispatcher;
	[iNotify sharedInstance].delegate = windowController.urlDispatcher;
	[iRate sharedInstance].delegate = windowController.urlDispatcher;
}

- (void)applicationWillTerminate:(NSNotification *)notification {
	
	NSApplication *application = [notification object];
	[windowController applicationWillTerminate:application];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)theApplication {
	
	return YES;
}

@end
