//
//  HoverButton.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 23/03/2011.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HoverButton : NSButton {
    
	NSTrackingArea *area;
}

@end
