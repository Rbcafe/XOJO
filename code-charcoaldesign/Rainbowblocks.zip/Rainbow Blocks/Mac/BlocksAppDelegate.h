//
//  RainbowBlocksAppDelegate.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/12/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class BlocksWindowController;

@interface BlocksAppDelegate : NSObject <NSApplicationDelegate> {
	
	NSWindow *window;
	BlocksWindowController *windowController;
}

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet BlocksWindowController *windowController;

@end
