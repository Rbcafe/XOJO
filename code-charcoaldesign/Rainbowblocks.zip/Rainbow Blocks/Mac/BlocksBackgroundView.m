//
//  BlocksBackgroundView.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 20/02/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import "BlocksBackgroundView.h"


@implementation BlocksBackgroundView

- (void)drawRect:(NSRect)dirtyRect {
	
	[[NSColor colorWithCalibratedRed:0.2 green:0.2 blue:0.25 alpha:1.0] set];
	NSRectFill(dirtyRect);
	
	NSShadow *shadow = [[[NSShadow alloc] init] autorelease];
	[shadow setShadowColor:[NSColor blackColor]];
	[shadow setShadowOffset:NSMakeSize(0, -5)];
	[shadow setShadowBlurRadius:70];
	[shadow set];
	
	NSRect shadowRect = [[[self subviews] objectAtIndex:3] frame];
	NSRectFill(shadowRect);
}

@end
