(function() {

	//***************
	// modal dialogs
	//***************
		
	var showTime;
	
	//generic modal
	function showDialog(html, buttons) {
		
		//set show time
		showTime = new Date();
		
		//remove existing modal
		$('#d').remove();
		
		//create modal
		var modal = $.extend({
			close: function(callback) {
				setTimeout(function() {
					veil.fadeOut();
					modal.animate({
						top: 100,
						left: 0
					}, function() {
						if (typeof(callback) == 'function') {
							callback.call(this);
						}
						$(this).remove();
					});
				}, 0);
			},
			addButton: function(name, callback) {
				modal.find('>div').append($('<div class="bt">' + name + '</div>').click(function(e) {
					if ((new Date()) - showTime > 500) {
						callback.call(modal);
					}
					return false;
				}));
			}
		}, $('<div id="d"><div>' + html + '</div></div>'));
		
		//add buttons
		if (typeof(buttons) == 'object') {
			for (name in buttons) {
				modal.addButton(name, buttons[name]);
			}
		}
		
		//create veil
		var veil = $('#v');
		if (veil.length == 0) {
			veil = $('<div id="v"></div>');
			veil.hide();
		} else {
			modal.css({
				opacity: 0
			});
		}
		
		//hide modal initially
		veil.append(modal);
		$('body').append(veil);
		modal.css({
			top: 100,
			opacity: 0
		});
		
		//show modal
		veil.fadeIn();
		modal.animate({
			top: 0,
			opacity: 1
		});
		
		//return modal object
		return modal;
	}
	
	//***************
	// game code
	//***************

	//game constants
	POINTS_PER_BLOCK = 5;
	STARTING_POINT_TARGET = 750;
	STARTING_MULTIPLIER = 1;
	MULTIPLIER_INCREMENT = 2;
	BONUS_START_PERCENT = 86;
	BONUS_START_AMOUNT = 25;
	BONUS_MULTIPLIER_INCREMENT = 2;
	
	//configuration constants
	STAGE_WIDTH = 14;
	STAGE_HEIGHT = 9;
	BLOCK_WIDTH = 34;
	BLOCK_HEIGHT = 33;
	POINTS_DISTANCE = 100;

	//itunes
	ITUNES_LINK = 'http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=355313284&mt=8';
	
	//block types
	SPECIAL = 's';
	BLOCKS = ['b1','b2','b3','b4','b5'];
	
	//get a random type
	function randomType() {
		return BLOCKS[Math.floor(Math.random() * BLOCKS.length)];
	}
	
	//block class
	function Block(_x, _y, _type, _id) {
		
		//private properties
		var element = null;
		var type = _type;
		var x = _x;
		var y = _y;
		var id = _id || uniqueId();
		
		//methods
		this.randomise = function(callback) {
			this.setType(randomType(), callback);
			return this;
		}
		this.moveTo = function(_x, _y, callback) {
			var css = {};
			if (x != _x) {
				x = _x;
				css.left = x*BLOCK_WIDTH;
			}
			if (y != _y) {
				y = _y;
				css.top = y*BLOCK_HEIGHT;
			}
			if (element) {
				if (typeof callback === 'function') {
					element.animate(css, callback);
				} else if (typeof callback !== 'undefined' && callback) {
					element.animate(css);
				} else {
					element.css(css);
				}
			} else if (typeof callback === 'function') {
				callback();
			}
			return this;
		}
		this.hasElement = function() {
			return (element)? true: false;
		}
		this.getElement = function() {
			if (!element) {
				if (id) {
					element = $('#' + id);
				} else {
					//create element
					id = uniqueId();
					element = $(this.html());
				}
			}
			return element;
		}
		this.setType = function(_type, callback, dontUpdateElement) {
			var oldType = type;
			type = _type;
			if (element && !dontUpdateElement) {			
				var parent = element.parent();
				if (typeof callback != 'undefined' && callback && parent.length) {
					callback = (typeof callback === 'function')? callback: function() {};
					if (!element.is(':visible')) {
						element.removeClass(oldType).addClass(type).fadeIn(callback);
					} else if (!element.hasClass(type)) {
						var oldElement = element;
						element = null;
						id = null;
						parent.append(this.getElement().hide().fadeIn(function () {
							oldElement.remove();
							callback();
						}));
					}
					return this;
				} else {
					element.removeClass(oldType).addClass(type)
					if (!element.is(':visible')) {
						element.show();
					}
				}
			}
			if (typeof callback === 'function') {
				callback();
			}
			return this;
		}
		this.getType = function() {
			return type;
		}
		this.getX = function() {
			return x;
		}
		this.getY = function() {
			return y;
		}
		this.getId = function() {
			return id;
		}
		this.setId = function(_id) {
			id = _id;
			element = null;
		}
		this.remove = function(callback) {
			if (element) {
				if (typeof callback !== 'unefined' && callback) {
					callback = (typeof callback === 'function')? callback: function() {};
					element.css('z-index', 1).fadeOut(function() {
						$(this).css('z-index', 'inherit');
						callback();
					});
				} else {
					element.hide();
				}
			} else if (typeof callback === 'function') {
				callback();
			}
			return this;
		}
		this.html = function(hidden) {
			var style = 'left:' + x*BLOCK_WIDTH + 'px;top:' + y*BLOCK_HEIGHT + 'px;';
			return '<div class="b ' + type + '" id="' + id + '" style="' + style + '"></div>';
		}
		
		//set type
		if (typeof _type === 'undefined') {
			this.randomise();
		}
	}
	
	//stage
	function Stage(_container, _touchEvent) {
		
		//private properties
		var blocks = [];
		var container = $(_container);
		var touchEvent = _touchEvent;

		var setBlocks = function(allBlocks) {
			var html = '';
			for (var i = 0; i < allBlocks.length; i++) {
				html += allBlocks[i].html();
			}
			container.html(html);
			for (var i = 0; i < allBlocks.length; i++) {
				allBlocks[i].getElement();
			}
		}
		
		this.reset = function() {
			var types = {};
			//set regular blocks
			for (var y = 0; y < STAGE_HEIGHT; y++) {
				blocks[y] = [];
				for (var x = 0; x < STAGE_WIDTH; x++) {
					types[y + '|' + x] = randomType();
				}
			}
			//add specials
			for (var i = Math.floor(Math.random() * 3) + 2; i > 0; i--) {
				var y = Math.floor(Math.random() * STAGE_HEIGHT);
				var x = Math.floor(Math.random() * STAGE_WIDTH);
				types[y + '|' + x] = SPECIAL;
			}
			//render blocks
			var allBlocks = [];
			for (id in types) {
				var yx = id.split('|');
				var y = yx[0];
				var x = yx[1];
				var block = new Block(x, y, types[id]);
				allBlocks.push(block);
				blocks[y][x] = block;
			}
			setBlocks(allBlocks);
		}
		this.getBlock = function(x, y) {
			return blocks[y][x];
		}
		this.moveBlock = function(fromX, fromY, toX, toY, callback) {		
			var block = blocks[fromY][fromX];
			if (block) {
				blocks[fromY][fromX] = null;
				blocks[toY][toX] = block.moveTo(toX, toY, callback);
			} else if (typeof callback === 'function') {
				callback();
			}
		}
		this.getCorner = function() {
			return blocks[STAGE_HEIGHT - 1][STAGE_WIDTH - 1];
		}
		this.randomiseBlocks = function(pivotx, pivoty, _callback) {		
			var animating = 0;
			var callback = (typeof _callback === 'function')? function() {
				animating --;
				if (animating === 0) {
					_callback();
				}
			}: undefined;
			//weights
			var weights = {};
			for (var i = 0 ; i < BLOCKS.length; i++) {
				weights[BLOCKS[i]] = 0;
			}
			//new block types
			var types = {};
			//specials
			var specials = 0;
			//randomise blocks
			for (var y = Math.max(0, pivoty - 2); y < Math.min(STAGE_HEIGHT, pivoty + 3); y++) {
				for (var x = Math.max(0, pivotx - 2); x < Math.min(STAGE_WIDTH, pivotx + 3); x++) {
					var block = blocks[y][x] 
					if (block) {
						if (block.getType() == SPECIAL) specials ++;
						var type = randomType();
						types[y + '|' + x] = type;
						weights[type]++;
					}
				}
			}
			//set pivot value to most common
			var highest = BLOCKS[0];
			var highestWeight = 0;
			for (i in weights) {
				if (weights[i] > highestWeight) {
					highest = i;
					highestWeight = weights[i];
				}
			}
			types[pivoty + '|' + pivotx] = highest;
			//restore specials
			for (var i = 1 ; i < specials; i++) {
				var x = pivotx, y = pivoty;
				while (!blocks[y][x] || (x == pivotx && y == pivoty)) {
					x = Math.min(STAGE_WIDTH - 1, Math.max(0, pivotx + Math.floor(Math.random() * 5) - 2));
					y = Math.min(STAGE_HEIGHT - 1, Math.max(0, pivoty + Math.floor(Math.random() * 5) - 2));
				}
				types[y + '|' + x] = SPECIAL;
			}
			//animate blocks
			for (id in types) {
				var yx = id.split('|');
				var y = yx[0];
				var x = yx[1];
				animating ++;
				blocks[y][x].setType(types[id], callback);
			}			
		}
		this.findNeighbours = function(x, y) {
			var _findNeighbours = function(x, y, block, checked, affected) {
				var _block = blocks[y][x];
				var id = y + '|' + x;
				if (!checked[id]) {
					checked[id] = true;
					if (block && _block && block.getType() == _block.getType()) {
						affected.push(_block);
						if (x > 0) _findNeighbours(x-1, y, block, checked, affected);
						if (x < STAGE_WIDTH - 1) _findNeighbours(x+1, y, block, checked, affected);
						if (y > 0) _findNeighbours(x, y-1, block, checked, affected);
						if (y < STAGE_HEIGHT - 1) _findNeighbours(x, y+1, block, checked, affected);
					}
				}
				return affected;
			}
			return _findNeighbours(x, y, blocks[y][x], [], []);
		}
		this.remove = function(x, y, callback) {
			var block = blocks[y][x];
			if (block) {
				blocks[y][x] = null;
				block.remove(callback);
			}
		}
		this.shiftDown = function(callback) {		
			var falling = 0;
			callback = (typeof callback === 'function')? callback: function() {};
			for (x = 0; x < STAGE_WIDTH; x++) {
				var shift = 0;
				for (y = STAGE_HEIGHT - 1; y >= 0; y--) {
					if (!blocks[y][x]) {
						shift++;
					} else if (shift > 0) {
						falling++;
						stage.moveBlock(x, y, x, y + shift, function() {
							falling--;
							if (falling == 0) {	
								callback();
							}
						});
					}
				}
			}
			if (falling == 0) {
				callback();
			}
		}
		this.shiftRight = function(callback) {
			var sliding = 0;
			var shift = 0;
			callback = (typeof callback === 'function')? callback: function() {};
			for (x = STAGE_WIDTH - 1; x >= 0; x--) {
				var shiftNeeded = true;
				for (y = 0; y < STAGE_HEIGHT; y++) {
					if (blocks[y][x]) {
						shiftNeeded = false;
						break;
					}
				}
				if (shiftNeeded) {
					shift++;
				} else if (shift > 0) {
					for (y = 0; y < STAGE_HEIGHT; y++) {
						if (blocks[y][x]) {
							sliding++;
							stage.moveBlock(x, y, x + shift, y, function() {
								sliding--;
								if (sliding == 0) {
									callback();
								}
							});
						}
					}
				}
			}
			if (sliding == 0) {
				callback();
			}
		}
		this.levelComplete = function() {
			for (var y = 0; y < STAGE_HEIGHT; y++) {
				for (var x = 0; x < STAGE_WIDTH; x++) {
					var block = blocks[y][x];
					if (block && (block.getType() == SPECIAL || this.findNeighbours(x, y).length > 1)) {
						return false;
					}
				}
			}
			return true;
		}
		this.percentComplete = function() {
			var total = STAGE_WIDTH * STAGE_HEIGHT;
			var complete = 0;
			for (var y = 0; y < STAGE_HEIGHT; y++) {
				for (var x = 0; x < STAGE_WIDTH; x++) {
					if (!blocks[y][x]) {
						complete++;
					}
				}
			}
			return Math.round(complete/total * 100);
		}
		this.showPoints = function(x, y, _points) {	
			var style = 'left:' + x*BLOCK_WIDTH + 'px;top:' + y*BLOCK_HEIGHT + 'px';
			var id = uniqueId();
			var points = $('<div class="points" id="' +id + '" style="' + style + '">' + _points + '</div>');
			container.append(points);
			points.animate({
				top: y*BLOCK_HEIGHT - POINTS_DISTANCE,
				left: x*BLOCK_WIDTH,
				opacity: 0
			}, 1000, function() {
				points.remove();
			});
		}
		
		//initialise blocks
		this.reset(false);

		//bind touch event
		var offsetX = container[0].offsetLeft;
		var offsetY = container[0].offsetTop - $('#h')[0].offsetTop;
		var blockWidth = container.width() / STAGE_WIDTH;
		var blockHeight = container.height() / STAGE_HEIGHT;
		container.mousedown(function(e) {
			var x = Math.floor((e.pageX - offsetX)/blockWidth);
			var y = Math.floor((e.pageY - offsetY)/blockHeight);
			touchEvent(blocks[y][x], x, y);
		});
	}
	
	//score and goals
	function HUD() {
		
		function refreshScore() {
			$('#hs span').text(score);
		}
		
		//methods
		this.refresh = function() {
			refreshScore();
			$('#hl span').text(level);
			$('#ht span').eq(0).text(targetScore);
		}
		this.refreshScore = refreshScore;
	}
	
	//game state
	var level = 1;
	var score = 0;
	var targetScore = STARTING_POINT_TARGET;
	var multiplier = STARTING_MULTIPLIER;
	var hud = new HUD();
	var stage = null;
	var game = null;
	var animating = false;
	var startedAnimating = null;
	var animationTimeout = null;
	var levelComplete = false;
	
	//get unique id
	var nextId = 0;
	function uniqueId() {
		return 'rb' + nextId ++;
	}
	
	//check if game is running
	function gameRunning() {
		return !$('#m').is(':visible');
	}
	
	//reset game
	function resetGame() {
		levelComplete = false;
		level = 1;
		score = 0;
		targetScore = STARTING_POINT_TARGET;
		multiplier = STARTING_MULTIPLIER;
	}
	
	//increment level
	function nextLevel() {
		level++;
		targetScore += STARTING_POINT_TARGET * multiplier;
		multiplier += MULTIPLIER_INCREMENT;
		stage.reset();
		hud.refresh();
		setTimeout(function() {
			levelComplete = false;
		}, 1000);
	}
	
	//click function
	function blockClicked(block, x, y) {
		
		function _startAnimating() {
			animating = true;
			startedAnimating = new Date();
			animationTimeout = setTimeout(_update, 850);
		}
		
		function _update() {
			clearTimeout(animationTimeout);
			animating = false;
			checkIfLevelEnded();
		}
		
		//time out animation lock in case of glitches
		if (animating && (new Date()) - startedAnimating > 800) {
			_update();
		}
		
		//don't support interaction while animating
		if (animating || levelComplete) {
			return false;
		}
		
		if (block) {
			if (block.getType() == SPECIAL) {
				//handle special
				
				//randomise surrounding blocks
				_startAnimating();
				stage.randomiseBlocks(x, y, _update);
			
			} else {
				//handle normal
		
				//find all affected blocks
				var affected = stage.findNeighbours(x, y);
			
				if (affected.length > 1) {
				
					//update score
					var points = affected.length * affected.length * POINTS_PER_BLOCK;
					score += points;
					hud.refreshScore();
					
					//display points
					stage.showPoints(x, y, points);
					
					//remove from stage
					for (i = 0; i < affected.length; i++) {
						stage.remove(affected[i].getX(), affected[i].getY(), true);
					}
					
					//shift blocks
					_startAnimating();
					stage.shiftDown(function() {
						stage.shiftRight(_update);
					});
				}
			}
		}
		
		//cancel event
		return false;
	}
	
	//calculate
	function completionBonus(percentComplete) {
		var bonus = 0;
		var bonusMultiplier = 1;
		for (var i = BONUS_START_PERCENT; i <= percentComplete; i++) {
			bonus += BONUS_START_AMOUNT * bonusMultiplier;
			bonusMultiplier += BONUS_MULTIPLIER_INCREMENT;
		}
		return bonus;
	}
	
	//modals
	
	function showMenu() {
		$('#m').fadeIn(function() {
			this.style = 'display:block';
			stage.reset();
		});
	}

	function showLevelComplete(completed, bonus) {
		showDialog(
			'<h1>Level ' + level + ' Complete</h1>' + 
			'<p>Score: ' + score + '</p>' +
			'<p>Completed: ' + completed + '%</p>' +
			'<p>Bonus: ' + bonus + '</p>', {
				'Continue': function() {
					this.close();
					nextLevel();
				}
			});
	}
	
	function showDemoGameOver(hitLimit) {
		var modal = showDialog(
			'<h1>Thanks For Playing</h1><p>If you like the game, please<br>buy the full version</p>', {
				'Buy Now':  function() {
					window.top.location = ITUNES_LINK;
				},
				'10': function() {}
			});
		var playAgainButton = modal.find('.bt:last');
		var countdown = setInterval(function() {
			var count = parseInt(playAgainButton.html());
			playAgainButton.html(--count);
			if (count < 0) {
				clearInterval(countdown);
				playAgainButton.html('Play Again');
				playAgainButton.mousedown(function() {
					resetGame();
					modal.close();
					showMenu();
					return false;
				});
			}
		}, 1000);
	}
	
	//check if level complete
	function checkIfLevelEnded() {
		if (levelComplete) {
			return;
		}
		if (stage.levelComplete()) {
			levelComplete = true;
			var completed = stage.percentComplete();
			var bonus = completionBonus(completed);
			score += bonus;
			if (score >= targetScore) {
				showLevelComplete(completed, bonus);
			} else {
                resetGame();
				showDemoGameOver();
			}
		}
	}

	//initialise
	function init() {

		//initialise stage
		stage = new Stage($('#s'), blockClicked);
		
		//menu screen
		$('#ng').click(function() {
			$('#m').fadeOut(hud.refresh);
			return false;
		});
		$('#in').click(function() {
			showInstructions();
			return false;
		});
		$('#bn').click(function() {
			window.top.location = ITUNES_LINK;
			return false;
		});
		
		$('#m').show();
	}
	
	//show instructions
	function showInstructions (callback) {
		var modal = showDialog(
			'<ul>' +
			'<li>Click on groups of adjacent blocks to remove them</li>' +
			'<li>Click on rainbow blocks to scramble surrounding blocks</li>' +
			'<li>Complete levels by removing all adjacent and rainbow blocks</li>' +
			'<li>Game ends when you do not have enough points to advance</li>' +
			'</ul>'
		);
		modal.addClass('wide');
		modal.addButton('OK', function() {
			modal.close(callback);
		});
	}
	
	//initialise
	$(init);
	
})();