How to compress
===============


HTML
------

http://www.design215.com/toolbox/whitespace.php


CSS
------

http://tools.w3clubs.com/cssmin/


JavaScript
------------

First use Google Closure compiler with Simple setting

http://closure-compiler.appspot.com/home

Next use Dean Edwards compressor with Base62 encode and shrink

http://javascriptcompressor.com/