//
//  URLDispatcher.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 23/03/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import "URLDispatcher.h"
#import "NSURL+QueryParams.h"
#import "SoundManager.h"
#import "Playlist.h"


@implementation URLDispatcher

@synthesize delegate;


- (void)audioCallback:(NSURL *)url {
    
    NSDictionary *params = [url queryParams];
	if ([[url path] isEqualToString:@"/switchTrack"]) {
		
		[[Playlist sharedInstance] next];
	
    } else if ([[url path] isEqualToString:@"/playSound"]) {
        
        [[SoundManager sharedManager] playSound:[params objectForKey:@"name"] looping:NO];
        
    } else if ([[url path] isEqualToString:@"/playSounds"]) {
        
        NSArray *names = [[params objectForKey:@"names"] componentsSeparatedByString:@","];
        for (NSString *name in names)
        {
            [[SoundManager sharedManager] playSound:name looping:NO];
        }
        
    } else if ([[url path] isEqualToString:@"/playMusic"]) {
        
        [[SoundManager sharedManager] playMusic:[params objectForKey:@"name"] looping:YES];
    
    } else if ([[url path] isEqualToString:@"/stopMusic"]) {
        
        [[SoundManager sharedManager] stopMusic];
    }
}

- (void)gameCenterCallback:(NSURL *)url {

    NSDictionary *params = [url queryParams];
	if ([[url path] isEqualToString:@"/enable"]) {
		
		//enable game center
        if ([(NSObject *)delegate respondsToSelector:@selector(enableGameCenter:)]) {
            [delegate enableGameCenter:NO];
        }
		[[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"gameCenterPrompted"];
        
	} else if ([[url path] isEqualToString:@"/disable"]) {
		
		//disable game center
		[[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"gameCenter"];
        
	} else if ([[url path] isEqualToString:@"/scores"]) {
		
		//show leaderboard
		NSString *difficulty = [params objectForKey:@"difficulty"];
        if ([(NSObject *)delegate respondsToSelector:@selector(showGlobalScores:)]) {
            [delegate showGlobalScores:difficulty];
        }
		
	} else if ([[url path] isEqualToString:@"/submit"]) {
		
		//submit score
        NSInteger score = [[params objectForKey:@"score"] integerValue];
		NSInteger level = [[params objectForKey:@"level"] integerValue];
		NSString *difficulty = [params objectForKey:@"difficulty"];
        if ([(NSObject *)delegate respondsToSelector:@selector(submitScore:level:difficulty:)]) {
            [delegate submitScore:score level:level difficulty:difficulty];
        }
    }
}

- (void)settingsCallback:(NSURL *)url {
	
	if ([[url path] isEqualToString:@"/update"]) {
		
		//update settings
		NSDictionary *params = [url queryParams];
        [delegate updateSettings:params];
    }
}

- (void)undoCallback:(NSURL *)url {
	
	if ([[url path] isEqualToString:@"/enable"]) {
		
		NSInteger undosRemaining = [[[url queryParams] objectForKey:@"remaining"] intValue];
        if ([(NSObject *)delegate respondsToSelector:@selector(updateUndo:)]) {
            [delegate updateUndo:undosRemaining];
        }
            
	} else if ([[url path] isEqualToString:@"/disable"]) {
        
		if ([(NSObject *)delegate respondsToSelector:@selector(updateUndo:)]) {
            [delegate updateUndo:0];
        }
	}
}


- (void)appCallback:(NSURL *)url {
	
	if ([[url path] isEqualToString:@"/quit"]) {
		
        if ([(NSObject *)delegate respondsToSelector:@selector(quit)]) {
            [delegate quit];
        }
	}
}

- (void)iVersionCallback:(NSURL *)url {
	
	if ([[url path] isEqualToString:@"/viewedRemote"]) {
		
		[[iVersion sharedInstance] openAppPageInAppStore];
        if ([(NSObject *)delegate respondsToSelector:@selector(exitFullScreen)]) {
            [delegate exitFullScreen];
        }
		
	} else if ([[url path] isEqualToString:@"/viewedLocal"]) {
        
		[iVersion sharedInstance].viewedVersionDetails = YES;
        
	} else if ([[url path] isEqualToString:@"/ignore"]) {
		
		NSDictionary *params = [url queryParams];
		[iVersion sharedInstance].ignoredVersion = [params objectForKey:@"version"];
		
	} else if ([[url path] isEqualToString:@"/remind"]) {
		
		[iVersion sharedInstance].lastReminded = [NSDate date];
	}
}

- (void)iNotifyCallback:(NSURL *)url {
	
	NSDictionary *params = [url queryParams];
	if ([[url path] isEqualToString:@"/viewed"]) {
		
		[[iNotify sharedInstance] setNotificationViewed:[params objectForKey:@"key"]];
		[iNotify sharedInstance].lastReminded = nil;
		
	} else if ([[url path] isEqualToString:@"/ignore"]) {
        
		[[iNotify sharedInstance] setNotificationIgnored:[params objectForKey:@"key"]];
		[iNotify sharedInstance].lastReminded = nil;
        
	} else if ([[url path] isEqualToString:@"/remind"]) {
		
		[iNotify sharedInstance].lastReminded = [NSDate date];
	}
}

- (void)iRateCallback:(NSURL *)url {
	
	if ([[url path] isEqualToString:@"/rated"]) {
		
		[[iRate sharedInstance] openRatingsPageInAppStore];
		[iRate sharedInstance].ratedThisVersion = YES;
        if ([(NSObject *)delegate respondsToSelector:@selector(exitFullScreen)]) {
            [delegate exitFullScreen];
        }
		
	} else if ([[url path] isEqualToString:@"/decline"]) {
		
		[iRate sharedInstance].declinedThisVersion = YES;
		
	} else if ([[url path] isEqualToString:@"/remind"]) {
		
		[iRate sharedInstance].lastReminded = [NSDate date];
	}
}

- (BOOL)dispatchURL:(NSURL *)url {
           
    if ([url host]) {
		if ([[url host] isEqualToString:@"gameCenter.rainbowblocks"]) {
			[self gameCenterCallback:url];
		} else if ([[url host] isEqualToString:@"settings.rainbowblocks"]) {
			[self settingsCallback:url];
		} else if ([[url host] isEqualToString:@"audio.rainbowblocks"]) {
			[self audioCallback:url];
		} else if ([[url host] isEqualToString:@"undo.rainbowblocks"]) {
			[self undoCallback:url];
		} else if ([[url host] isEqualToString:@"app.rainbowblocks"]) {
			[self appCallback:url];
		} else if ([[url host] isEqualToString:@"iVersion.rainbowblocks"]) {
			[self iVersionCallback:url];
		} else if ([[url host] isEqualToString:@"iNotify.rainbowblocks"]) {
			[self iNotifyCallback:url];
		} else if ([[url host] isEqualToString:@"iRate.rainbowblocks"]) {
			[self iRateCallback:url];
		} else {
            if ([(NSObject *)delegate respondsToSelector:@selector(exitFullScreen)]) {
                [delegate exitFullScreen];
            }
            [delegate openExternalURL:url];
		}
		return YES;
	} else {
		return NO;
	}
}

#pragma mark -
#pragma mark iVersionDelegate methods

- (NSString *)processedVersionNumber:(NSString *)version
{
#ifdef __IPHONE_OS_VERSION_MAX_ALLOWED
    float pointVersion = [[version pathExtension] floatValue] / 10.0;
    int part0 = [[version stringByDeletingPathExtension] intValue];
    int part1 = floor(pointVersion);
    int part2 = round((pointVersion - (float)part1) * 100.0)/10.0;
    if (part2) {
        return [NSString stringWithFormat:@"%i.%i.%i", part0, part1, part2];
    } else {
        return [NSString stringWithFormat:@"%i.%i", part0, part1];
    }
#else
    return version;
#endif
}

- (BOOL)iVersionShouldDisplayNewVersion:(NSString *)version details:(NSString *)versionDetails {
    
    versionDetails = [versionDetails stringByReplacingOccurrencesOfString:@"\n" withString:@"\\n"];
	NSString *alertString = [NSString stringWithFormat:@"Blocks.showNewVersion(\"%@\", \"%@\")", [self processedVersionNumber:version], versionDetails];
	[delegate executeJavaScript:alertString];
	return NO;
}

- (BOOL)iVersionShouldDisplayCurrentVersionDetails:(NSString *)versionDetails {
	
	versionDetails = [versionDetails stringByReplacingOccurrencesOfString:@"\n" withString:@"\\n"];
	NSString *alertString = [NSString stringWithFormat:@"Blocks.showCurrentVersion(\"%@\", \"%@\")",
							 [self processedVersionNumber:[iVersion sharedInstance].applicationVersion],
                             versionDetails];
	[delegate executeJavaScript:alertString];
	return NO;
}

#pragma mark -
#pragma mark iNotifyDelegate methods

- (BOOL)iNotifyShouldDisplayNotificationWithKey:(NSString *)key details:(NSDictionary *)details {
	
	NSString *title = [details objectForKey:iNotifyTitleKey];
	NSString *message = [details objectForKey:iNotifyMessageKey];
	NSString *actionURL = [details objectForKey:iNotifyActionURLKey];
	NSString *actionButtonLabel = [details objectForKey:iNotifyActionButtonKey];
	if (!actionButtonLabel) {
		actionButtonLabel = [iNotify sharedInstance].defaultActionButtonLabel;
	}
	NSString *alertString = [NSString stringWithFormat:@"Blocks.showNotification(\"%@\", \"%@\", \"%@\", \"%@\", \"%@\")",
							 key, title, message, actionURL, actionButtonLabel];
	
	[delegate executeJavaScript:alertString];
	return NO;
}

#pragma mark -
#pragma mark iRateDelegate methods

- (BOOL)iRateShouldShouldPromptForRating {
	
	[delegate executeJavaScript:@"Blocks.showRatingPrompt()"];
	return NO;
}

@end
