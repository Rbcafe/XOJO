//
//  URLDispatcher.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 23/03/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "iVersion.h"
#import "iNotify.h"
#import "iRate.h"


@protocol URLDispatcherDelegate

- (void)openExternalURL:(NSURL *)url;
- (void)updateSettings:(NSDictionary *)params;
- (void)executeJavaScript:(NSString *)script;

@optional

- (void)updateUndo:(NSUInteger)undosRemaining;
- (void)exitFullScreen;
- (void)quit;
- (void)enableGameCenter:(BOOL)prompt;
- (void)showGlobalScores:(NSString *)difficulty;
- (void)submitScore:(NSInteger)score level:(NSInteger)level difficulty:(NSString *)difficulty;

@end


@interface URLDispatcher : NSObject <iVersionDelegate, iRateDelegate, iNotifyDelegate> {
    
    id<URLDispatcherDelegate> delegate;
}

@property (nonatomic, assign) id<URLDispatcherDelegate> delegate;

- (BOOL)dispatchURL:(NSURL *)url;

@end
