//
//  Playlist.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/03/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import "Playlist.h"
#import "SoundManager.h"
#import "NSArray+Shuffle.h"


static Playlist *sharedInstance = nil;


@interface Playlist ()

@property (nonatomic, retain) NSArray *tracks;

@end


@implementation Playlist

@synthesize shuffle;
@synthesize tracks;

+ (Playlist *)sharedInstance
{
    if (!sharedInstance)
    {
        sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

- (void)setTracks:(NSArray *)_tracks
{
    if (tracks != _tracks)
    {
        [tracks release];
        tracks = [_tracks copy];
    }
    if (shuffle)
    {
        [tracks autorelease];
        tracks = [[tracks shuffledArray] retain];
    }
}

- (void)setShuffle:(BOOL)_shuffle
{
    shuffle = _shuffle;
    if (shuffle)
    {
        [tracks autorelease];
        tracks = [[tracks shuffledArray] retain];
    }
}

- (void)play
{
    [[SoundManager sharedManager] playMusic:[tracks objectAtIndex:trackIndex] looping:YES];
}

- (void)stop
{
    [[SoundManager sharedManager] stopMusic];
}

- (void)next
{
    if (![[SoundManager sharedManager] playingMusic])
    {
        [self play];
    }
    else
    {
        trackIndex++;
        trackIndex = trackIndex % [tracks count];
        [[SoundManager sharedManager] playMusic:[tracks objectAtIndex:trackIndex] looping:YES];
    }
}

- (void)dealloc
{
    [tracks release];
    [super dealloc];
}

@end
