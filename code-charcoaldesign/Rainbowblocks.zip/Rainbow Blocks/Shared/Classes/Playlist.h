//
//  Playlist.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 27/03/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Playlist : NSObject
{    
    BOOL shuffle;
    NSArray *tracks;
    NSUInteger trackIndex;
}

+ (Playlist *)sharedInstance;

@property (nonatomic, assign) BOOL shuffle;

- (void)setTracks:(NSArray *)tracks;

- (void)play;
- (void)stop;
- (void)next;

@end
