//
//  NSArray+Shuffle.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 29/01/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSArray(Shuffle)

- (NSArray *)shuffledArray;

@end


@interface NSMutableArray(Shuffle)

- (void)shuffle;

@end
