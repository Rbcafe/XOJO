//
//  NSArray+Shuffle.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 29/01/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import "NSArray+Shuffle.h"


@interface NSObject(Shuffle)

- (NSComparisonResult)shuffleCompare:(id)object;

@end


@implementation NSObject(Shuffle)

- (NSComparisonResult)shuffleCompare:(id)object
{
	return (rand() > (INT_MAX/2))? NSOrderedAscending: NSOrderedDescending;
}

@end


@implementation NSArray(Shuffle)

- (NSArray *)shuffledArray
{
	return [self sortedArrayUsingSelector:@selector(shuffleCompare:)];
}

@end


@implementation NSMutableArray(Shuffle)

- (void)shuffle
{
	[self sortUsingSelector:@selector(shuffleCompare:)];
}

@end