//
//  NSURL+QueryParams.m
//  RainbowBlocks
//
//  Created by Nick Lockwood on 03/10/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import "NSURL+QueryParams.h"


@implementation NSURL(QueryParams)

- (NSString *)urlDecode:(NSString *)text {
	
	return [text stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

- (NSDictionary *)queryParams {
	
	NSMutableDictionary *params = [NSMutableDictionary dictionary];
	NSArray *pairs = [[self query] componentsSeparatedByString:@"&"];
	for (NSString *pair in pairs) {
		NSArray *components = [pair componentsSeparatedByString:@"="];
		[params setObject:[self urlDecode:[components objectAtIndex:1]]
				   forKey:[self urlDecode:[components objectAtIndex:0]]];
	}
	return params;
}

@end
