//
//  NSURL+QueryParams.h
//  RainbowBlocks
//
//  Created by Nick Lockwood on 03/10/2010.
//  Copyright 2010 Charcoal Design. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSURL(QueryParams)

- (NSDictionary *)queryParams;

@end
