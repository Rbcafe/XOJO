//
//  AppDelegate.h
//  FileSuffixesTest
//
//  Created by Nick Lockwood on 08/06/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
