//
//  ViewController.h
//  FileSuffixesTest
//
//  Created by Nick Lockwood on 08/06/2012.
//
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIImageView *imageView1;
@property (nonatomic, strong) IBOutlet UIImageView *imageView2;

@end
