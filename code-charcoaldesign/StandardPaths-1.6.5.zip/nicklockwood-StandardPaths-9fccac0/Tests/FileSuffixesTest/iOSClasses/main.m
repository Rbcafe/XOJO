//
//  main.m
//  FileSuffixesTest
//
//  Created by Nick Lockwood on 08/06/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
