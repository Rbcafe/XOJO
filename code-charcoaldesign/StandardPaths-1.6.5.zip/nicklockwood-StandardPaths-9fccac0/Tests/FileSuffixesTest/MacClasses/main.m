//
//  main.m
//  FileSuffixesTestMac
//
//  Created by Nick Lockwood on 09/06/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
