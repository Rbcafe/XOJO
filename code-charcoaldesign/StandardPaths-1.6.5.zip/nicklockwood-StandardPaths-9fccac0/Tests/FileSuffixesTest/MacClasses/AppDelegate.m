//
//  AppDelegate.m
//  FileSuffixesTestMac
//
//  Created by Nick Lockwood on 09/06/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(__unused NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
