//
//  AppDelegate.h
//  FileSuffixesTestMac
//
//  Created by Nick Lockwood on 09/06/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (nonatomic, assign) IBOutlet NSWindow *window;
@property (nonatomic, assign) IBOutlet NSWindowController *windowController;

@end
