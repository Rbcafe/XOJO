//
//  GLViewImageMapController.h
//  GLImageDemo
//
//  Created by Nick Lockwood on 05/06/2012.
//
//

#import <UIKit/UIKit.h>

@interface GLViewImageMapController : UITableViewController

@end
