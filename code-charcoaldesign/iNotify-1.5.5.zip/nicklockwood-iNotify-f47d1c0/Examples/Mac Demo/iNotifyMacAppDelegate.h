//
//  iNotifyMacAppDelegate.h
//  iNotifyMac
//
//  Created by Nick Lockwood on 05/02/2011.
//  Copyright 2011 Charcoal Design. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface iNotifyMacAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
