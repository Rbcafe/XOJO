//
//  ViewController.h
//  BasicAuth
//
//  Created by Nick Lockwood on 17/05/2012.
//  Copyright (c) 2012 Charcoal Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic) IBOutlet UIImageView *imageView;

@end
